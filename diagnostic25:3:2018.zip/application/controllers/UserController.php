<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class UserController extends CI_Controller {

	//Constructor Function
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('UserModel');

	}

	//Login Index Page
	public function index()
	{	if($this->UserModel->ChecKLogin()==TRUE){
			redirect('dashboard','refresh');
		}else{
			$this->load->view('login');
		}
	}

	//Try For Login
	public function TryLogin(){
		$this->form_validation->set_rules('password', 'Password', 'required');		
		$this->form_validation->set_rules('username', 'Username', 'required');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		}else{
			if($this->UserModel->TryLogin()==TRUE){
				redirect('dashboard','refresh');
			}else{
				redirect('admin-login?action=failed','refresh');
			}
		}
	}


	public function Logout(){
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('name');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('role');
		$this->session->unset_userdata('password');		
		$this->session->unset_userdata('user_id');
		
 		$this->session->sess_destroy();
        redirect('admin-login/?logout=success');
	}






#End Of File
}

/* End of file UserController.php */
/* Location: ./application/controllers/UserController.php */