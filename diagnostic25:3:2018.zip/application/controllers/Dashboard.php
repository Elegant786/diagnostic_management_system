<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('UserModel');
		$this->load->model('DashboardModel');
		if($this->UserModel->ChecKLogin()==FALSE){
			redirect('admin-login?action=no-session','refresh');
		}
		$this->load->library('pagination');
		
	}

	//Dashbord Page
	public function index(){
		$data = array(
			"page" => 'home',
			"title"  => "Dashboard | Home"
			
		);
		$this->load->view('index',$data);
	}


	/**********************************
	===============EditDoctor=============
	***************************************/
	//Doctor Create
	public function NewDoctor(){
		$data = array(
			"page"   	=> "new-doctor",
			"title"     => "Dashboard | New doctor"
		);
		$this->load->view('index',$data);
	}
	//Edit Doctor
	public function EditDoctor(){
		$data = array(
			"page"   	=> "new-doctor",
			"title"     => "Dashboard | Edit Doctor"
		);
		$this->load->view('index',$data);
	}
	//Delete Doctor
	public function DeleteDoctor(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `doctors` WHERE `doc_id` = '$id' ");
		redirect('dashboard/new-doctor','refresh');
	}

	/************************************
		Test management
	*****************************************/
	// Test Create
	public function TestManage(){
		$data = array(
			"page"		=> "test-manage",
			"title"		=> "Test Management"
		);
		$this->load->view('index',$data);
	}

	//Edit Test

	public function TestEdit(){
		$data = array(
			"page"		=> "test-manage",
			"title"		=> "Test Edit"
		);
		$this->load->view('index',$data);
	}

	//Delete Test
	public function TestDelete(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `tests` WHERE `test_id` = '$id' ");
		redirect('dashboard/test-management','refresh');
	}
	//Test Attribute Add
	public function TestAttributes(){
		$data = array(
			"page" 		=> "test-attr",
			"title"		=> "Test Attribute"
		);
		$this->load->view('index',$data);
	}

	//TestReport
	public function TestReport(){
		$data = array(
			"page" 		=> "test-report",
			"title"		=> "Test Attribute"
		);
		$this->load->view('index',$data);
	}

	public function GenerateReport(){
		$data = array(
			"page" 		=> "test-generate",
			"title"		=> "Generate Report"
		);
		$this->load->view('index',$data);
	}


	public  function PrintTestReport(){
		$this->load->view('print-report');
	}

	public function SaveTestReport(){
		$this->load->view('print-report_2');
	}

/************************************************************
				Patient Test Management
************************************************************/

	public function NewTest(){
		$data = array(
			"page"	=> "new-test",
			"title" => "Patent Test"
		);
		$this->load->view('index',$data);
	}

	public function DoTest(){
		$data = array(
			"page"	=> "do-test",
			"title" => "Patent Test"
		);
		$this->load->view('index',$data);
	}

	public function PrintInvoice(){
		$this->load->view('invoice');
	}

	public function InvoiceSave(){
		$this->load->view('invoice_preview');
	}

	/*************************************************
			==============Accounts============
	*************************************************/

	public function AccountsResult(){
		$data = array(
			"page"	=> "account-result",
			"title" => "Accounts Report"
		);
		$this->load->view('index',$data);
	}

	public function AllInvoices(){
		$data = array(
				"page" => "invoice-hostory",
				"title" => "Invoice Histories"
			);
		$this->load->view('index',$data);

	}

	public function TestCompletes(){
		$num =$this->DashboardModel->CountTest();
            $config=array(

                    'base_url'           =>     base_url('dashboard/test-completes'),
                    'per_page'           =>     1,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination-sm no-margin pull-right pagination">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );
            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->getTestsResult($config['per_page'], $this->uri->segment(5));
		$data = array(
			"page"	  => "test-compltes",
			"result"  => $result
		);
		$this->load->view('index',$data);
	}

/*******************************************************************************
						Ajax Functions
*******************************************************************************/
	public function getTestprice(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$id'  ");
		$result['test'] = $query->result();
		$this->load->view('pages/ajax_price',$result);
	}



/*******  ********************
	Change User Password

********************************/

public function ChangePassword(){
	$data = array(
			"page"		=> "change-password",

		);
	$this->load->view('index',$data);
}

public function Profile(){
	$data = array(
			"page"	=> "profile"
		);
	$this->load->view('index',$data);
}



/***************************************
			Dashboards
****************************************/
public function AllDoctors(){
	$data = array(
		"page"	=> 'all-docs'
	);
	$this->load->view('index',$data);
}

public function AllTests(){
	$data = array(
		"page"	=> 'all-tests'
	);
	$this->load->view('index',$data);
}

public function AllPatients(){
	$data = array(
		"page"	=> 'all-patients'
	);
	$this->load->view('index',$data);
}

/************************************
	Due payment
****************************************/
	public function DuePayment(){
		$data = array(
			'page'	=> "due-pay"
		);	
		$this->load->view('index',$data);
	}
	#End Of File
}

/* End of file Dashboard.php */
/* Location: ./application/controllers/Dashboard.php */