<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserModel extends CI_Model {
	public function __construct(){
		parent::__construct();
		//Do your magic here
	}	
	//Try For Login 
	public function TryLogin(){
		
		$username = $this->input->post('username');
		$password = md5("Elegant@2018".$this->input->post('password'));
		$query = $this->db->select("*")
					      ->from('users')
					      ->where('username',$username)
					      ->where('password',$password)
					      ->get();
		if($query->num_rows()==1){
			$session = array(
				"name"      => $query->row(0)->name,
				"username"  => $query->row(0)->username,
				"password"  => $query->row(0)->password,
				"email"  	=> $query->row(0)->email,
				"role"  	=> $query->row(0)->role,
				"user_id"   => $query->row(0)->user_id
			);
			$this->session->set_userdata($session);
			return TRUE;
		}else{
			return FALSE;
		}

	}

	// Check Logind Or Not

	public function ChecKLogin(){
		if($this->session->userdata('user_id')!=NULL || $this->session->userdata('user_id')>0){
			return  TRUE;
		}else{
			return FALSE;
		}
	}	

}

/* End of file UserModel.php */
/* Location: ./application/models/UserModel.php */