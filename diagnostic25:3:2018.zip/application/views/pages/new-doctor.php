<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Create New Doctor</h6>
									</div>
								</div>
								
							</div>
						</div>
					</header>

<div class="main-content">
		<?php
			if(isset($_POST['submit'])){
				$id = $this->input->post('id');
				$name = $this->input->post('name');
				$hospital = $this->input->post('hospital');
				$gender = $this->input->post('gender');
				$deg = $this->input->post('deg');
				$spe = $this->input->post('spe');

				$attr = array(
					"doc_code" =>  $id,
					"doc_name" =>  $name,
					"hos_name" =>  $hospital,
					"gender"   =>  $gender,
					"deg"	   => $deg,
					'spe'	   => $spe
				);

				if($this->db->insert('doctors',$attr)){
					echo "<div class='row'> <div class='col-md-12'> <div class='alert bg-success text-center font-white'> Doctor Added </div> </div></div>";
				}else{
					echo "<div class='row'> <div class='col-md-12'> <div class='alert bg-danger text-center font-white'> Doctor Not Added Added </div> </div></div>";
				}
			}

			if(isset($_POST['update'])){
				$id = $this->input->post('id');
				$name = $this->input->post('name');
				$hospital = $this->input->post('hospital');
				$gender = $this->input->post('gender');
				$deg = $this->input->post('deg');
				$spe = $this->input->post('spe');

				$attr = array(
					"doc_code" =>  $id,
					"doc_name" =>  $name,
					"hos_name" =>  $hospital,
					"gender"   =>  $gender,
					"deg"	   => $deg,
					'spe'	   => $spe
				);
				$this->db->where('doc_code',$id);
				if($this->db->update('doctors',$attr)){
					echo "<div class='row'> <div class='col-md-12'> <div class='alert bg-success text-center font-white'> Doctor's Data Updated </div> </div></div>";
				}else{
					echo "<div class='row'> <div class='col-md-12'> <div class='alert bg-danger text-center font-white'> Doctor's Data Not Updated </div> </div></div>";
				}
			}
		?>

	<div class="row">

		<?php if($this->uri->segment(3)){?>
			<div class="col-md-5">
				<div class="card top-blue-bdr">
					<div class="card-header">Edit Doctor</div>
					<div class="card-body">

						<?php echo form_open();
							$doc_id = $this->uri->segment(3);
							$query = $this->db->query("SELECT * FROM `doctors` WHERE `doc_id` = '$doc_id' ");
							$result = $query->result();
							foreach($result AS $row){
						?>
								<div class="form-group">
									<label>Doctor ID</label>
									<input type="hidden" name="id" class="form-control" value="<?php echo $row->doc_code?>">
									<input type="text" disabled="" name="id" class="form-control" value="<?php echo $row->doc_code?>">
								</div>
								<div class="form-group">
									<label>Doctor Name</label>
									<input type="text" value="<?php echo $row->doc_name?>" required name="name" class="form-control">
								</div>
								
								<div class="form-group">
									<label>Hospital Name</label>
									<input type="text" value="<?php echo $row->hos_name?>" required name="hospital" class="form-control">
								</div>

								<div class="form-group">
									<label>Doctor's Digree</label>
									<input type="text" value="<?php echo $row->deg?>" required name="deg" class="form-control">
								</div>

								<div class="form-group">
									<label>Specialist</label>
									<input type="text" value="<?php echo $row->spe?>" required name="spe" class="form-control">
								</div>
								
								<div class="form-group">
										<?php
											if($row->gender==1){

										?>
										<label>Gender</label><br>
										<label><input type="radio" checked name="gender" value="1"> Male</label> &nbsp	
										<label><input type="radio" name="gender" value="0">Female</label>
										<?php }else{?>
										<label>Gender</label><br>
										<label><input type="radio" name="gender" value="1"> Male</label> &nbsp	
										<label><input type="radio" checked name="gender" value="0">Female</label>
										<?php }?>
										
								</div>

								<div class="form-group">
									<button class="btn btn-success" type="submit" name="update">Update</button>
								</div>	
						<?php } echo form_close()?>
					</div>
				</div>
			</div>
		<?php }else{?>
			<div class="col-md-5">
				<div class="card top-blue-bdr">
					<div class="card-header">New Doctor</div>
					<div class="card-body">
						<?php echo form_open()?>
								<div class="form-group">
									<label>Doctor ID</label>
									<input type="hidden" name="id" class="form-control" value="<?php echo date('Ydmihs')?>">
									<input type="text" disabled="" name="id" class="form-control" value="<?php echo date('Ydmihs')?>">
								</div>
								<div class="form-group">
									<label>Doctor Name</label>
									<input type="text" required name="name" class="form-control">
								</div>
								
								<div class="form-group">
									<label>Hospital Name</label>
									<input type="text" required name="hospital" class="form-control">
								</div>

								<div class="form-group">
									<label>Doctor's Digree</label>
									<input type="text" required name="deg" class="form-control">
								</div>

								<div class="form-group">
									<label>Specialist</label>
									<input type="text" required name="spe" class="form-control">
								</div>
								
								<div class="form-group">
										<label>Gender</label><br>
										<label><input type="radio" name="gender" value="1"> Male</label> &nbsp	
										<label><input type="radio" name="gender" value="0">Female</label>
								</div>

								<div class="form-group">
									<button class="btn btn-success" type="submit" name="submit"> Add New</button>
								</div>	
						<?php echo form_close()?>
					</div>
				</div>
			</div>
			<div class="col-md-7">
				<div class="card top-blue-bdr">
					<div class="card-header">Doctors</div>
						<div class="card-body">
							<table class="table table-bordered table-responsive">
									<thead>
										<tr>
											
											<th>Doctor Name</th>
											<th>Hospital name</th>
											<th>Digree</th>
											<th>Specialis</th>
											<th>Action</th>
										</tr>
									</thead>
									  <tbody>
									  	<?php
									  		$query = $this->db->get("doctors");
									  		$result = $query->result();
									  		foreach($result AS $row){
									  	?>
										<tr>											
											<td><?php echo $row->doc_name?></td>
											<td><?php echo $row->hos_name?></td>
											<td><?php echo $row->deg?></td>
											<td><?php echo $row->spe?></td>
											<td>
												<div class="btn-group">
												  <button type="button" class="btn btn-light">Action</button>
												  <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												    <span class="sr-only">Toggle Dropdown</span>
												  </button>
												  <div class="dropdown-menu">
												    <a class="dropdown-item" href="<?php echo base_url()?>dashboard/doc-edit/<?php echo $row->doc_id;?>">Edit</a>
												    <div class="dropdown-divider"></div>
												    <a class="dropdown-item" href="<?php echo base_url()?>dashboard/doc-delete/<?php echo $row->doc_id;?>">Delete</a>
												  </div>
												</div>
											</td>
										</tr>
										<?php }?>
									</tbody>
							</table>
						</div>
				</div>
			</div>
	<?php }?>
	</div>
</div>

</div>