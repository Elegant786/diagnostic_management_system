<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Welcome to Unify Admin Template</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login">Last Login: 2 hours ago</span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
					
						
		<?php
			if(!isset($_POST['search'])){
		?>
			<div class="row">
							<div class="col-md-12">
								<div class="card top-blue-bdr">
										<div class="card-header">Generate Test</div>
											<div class="card-body">
										<?php echo form_open()?>
										<table class="table table-bordered table-responsive">
											<thead>
												<tr>
													<th>
														<div class="form-group">
															<label>Date From</label>
															<input type="date" class="form-control" name="date1">
														</div>
													</th>
													<th>
														<div class="form-group">
															<label>Date To</label>
															<input type="date" class="form-control" name="date2">
														</div>
													</th>
													<th>
														<div class="form-group">
															<label>Invoice</label>
															<input type="text" class="form-control" name="invoie">
														</div>
													</th>
													<th>
														<div class="form-group">
															<button class="btn btn-success" type='submit' name='search'> Search </button>
														</div>
													</th>
												</tr>
											</thead>
										</table>
										<?php echo form_close()?>
											</div>
										</div>
								</div>
			</div>
						<div class="row">
							<div class="col-md-12">
									<div class="card top-blue-bdr">
										<div class="card-header">Generate Test</div>
											<div class="card-body">
												<table class="table table-bordered table-responsive">
													<thead>

														<tr>
															<th>P.Name</th>
															<th>Test Name</th>
															<th>Date</th>
															<th>Action</th>
														</tr>
													</thead>

													<tbody>
														<?php
															foreach($result AS $row){
														?>
														<tr>
															
															<td>
																<?php
																	$query = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$row->pid'  ");
																	if($query->num_rows()==1){
																	echo $query->row(0)->patien_name;
																}
																?>
															</td>
															<td>
																<?php
																	$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$row->test_id'  ");
																	if($query->num_rows()==1){
																	echo $query->row(0)->test_name;
																}
																?>
															</td>
															<td><?php echo $row->date?></td>
															
															<td>
																<a target="_blank" class='btn btn-outline-light btn-rounded btn-sm' href="<?php echo base_url()?>save-report?pid=<?php echo $row->pid?>&report=<?php echo $row->rep_code?>">View</a>
															</td>
														</tr>
														<?php }?>

														<tr>
															<td colspan="4"><?php echo $this->pagination->create_links()?></td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
						</div>
		<?php }else{


			?>

				
						<div class="row">
							<div class="col-md-12">
								<div class="card top-blue-bdr">
										<div class="card-header">Search</div>
											<div class="card-body">
								<?php echo form_open(); 
									
								?>
									<table class="table table-bordered table-responsive">
										<thead>
											<tr>
												<th>
													<div class="form-group">
														<label>Date From</label>
														<input type="date"  value="<?php if(isset($_POST['date1'])){ echo $_POST['date1']; }?>" class="form-control" name="date1">
													</div>
												</th>
												<th>
													<div class="form-group">
														<label>Date To</label>
														<input type="date" value="<?php if(isset($_POST['date2'])){ echo $_POST['date2']; }?>"  class="form-control" name="date2">
													</div>
												</th>
												<th>
													<div class="form-group">
														<label>Invoice</label>
														<input type="text" class="form-control" name="invoie">
													</div>
												</th>
												<th>
													<div class="form-group">
														<button class="btn btn-success" type='submit' name='search'> Search </button>
													</div>
												</th>
											</tr>
										</thead>
									</table>
									<?php echo form_close()?>
								</div>
							</div>
					</div>
				</div>

					<div class="row">
						<div class="col-md-12">
							<div class="card top-blue-bdr">
								<div class="card-header">Search</div>
								<div class="card-body">
									
									<table class="table table-border table-responsive">
											<thead>

												<tr>
													<th>P.Name</th>
													<th>Test Name</th>
													<th>Date</th>
													<th>Action</th>
												</tr>
											</thead>

											<tbody>
										<?php
											$date1 = $_POST['date1'];
											$date2 = $_POST['date2'];
											$inv   =   $_POST['invoie'];

											$sql = "SELECT * FROM `test_inv` ";
												if(isset($_POST['invoie']) && $_POST['invoie']!=NULL){
													$sql.="WHERE `inv_no` = '$inv'  AND `action` = 1 ";
												}elseif(!empty($_POST['date1']) && empty($_POST['date2'])){
													$sql.=" WHERE `date` = '$date1' AND `action` = 1";
												}
												elseif(empty($_POST['date1']) && !empty($_POST['date2'])){
													$sql.=" WHERE `date` = '$date2' AND `action` = 1 ";
												}
												elseif(empty($_POST['date1']) && !empty($_POST['date2'])){
													$sql.=" WHERE `date` BETWEEN '$date1' AND '$date2' AND `action` = 1";
												}
															$query = $this->db->query($sql);
															$tests = $query->result();
															
															foreach($tests AS $row){
										?>
														<tr>
															
															<td>
																<?php

																	$query = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$row->pat_code'  ");
																	if($query->num_rows()==1){
																	echo $query->row(0)->patien_name;
																}
																?>
															</td>
															<td>
																<?php
																	$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$row->test_id'  ");
																	if($query->num_rows()==1){
																	echo $query->row(0)->test_name;
																}
																?>
															</td>
															<td><?php echo $row->date?></td>
															
															<td>
																
																<?php
																	$query = $this->db->query("SELECT DISTINCT `rep_code` FROM `test_history` WHERE `test_id` = '$row->test_id' AND `pid` = '$row->pat_code'   ");
																	$result = $query->result();
																	foreach($result AS $row2){
																?>

																<a target="_blank" class='btn btn-outline-light btn-rounded btn-sm' href="<?php echo base_url()?>save-report?pid=<?php echo $row->pat_code?>&report=<?php echo $row2->rep_code?>">View</a>
																<?php }?>
															</td>
														</tr>
														<?php }?>

														<tr>
															<td colspan="4"><?php echo $this->pagination->create_links()?></td>
														</tr>
													</tbody>
									</table>



								</div>
							</div>
							
							
						</div>
					</div>


























	<?php }?>
					</div>

</div>