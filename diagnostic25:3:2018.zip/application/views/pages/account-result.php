<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">	
						<?php
							if(!isset($_POST['submit'])){
						?>
						<div class="row">
								<div class="col-md-12">
									<div class="card top-blue-bdr">
										<div class="card-header">Account Form</div>
										<div class="card-body">	
											<?php echo form_open()?>
											<table class="table table-responsive">
												<tr class="text-center">
													<th>
														<div class="form-group">
															<label>Date From</label>
															<input type="date" name="date1" class="col-md-5 form-control">
														</div>
													</th>													
													<th>
														<div class="form-group">
															<label>Date To</label>
															<input type="date" name="date2" class="col-md-5 form-control">
														</div>
													</th>
													
												</tr>
												<tr>
													<td>
														<div class="form-group">
															<label>Test</label>
															<select name="test" class="form-control">
															<option value="0">Please select</option>
															<?php 
																$query = $this->db->get('tests');
																$result = $query->result();
																foreach($result AS $row){
																	echo "<option value='{$row->test_id}'>{$row->test_name}</option>";
																}
															?>
															</select>
														</div>
													</td>
													<td>
														<div class="form-group">
															<label>Doctor</label>
															<select name="doc" class="form-control">
															<option value="0">Please select</option>
															<?php 
																$query = $this->db->get('doctors');
																$result = $query->result();
																foreach($result AS $row){
																	echo "<option value='{$row->doc_id}'>{$row->doc_name}</option>";
																}
															?>
															</select>
														</div>
													</td>
												</tr>
												<tr>
													<td colspan="2">
														<div class="form-group">
															<label>Invoice No</label>
															<input type="text" name="inv" class="col-md-6 form-control" placeholder="invoice number ">
														</div>
													</td>
												</tr>

												<tr>
													<th colspan="2">
														<button class="btn btn-success" name="submit" type="submit">Submit</button>
													</th>
												</tr>
											</table>
											<?php echo form_close()?>
										</div>
									</div>
								</div>
						</div>	
					<?php }else{?>

					<div class="row">
								<div class="col-md-12">
									<div class="card top-blue-bdr">
										<div class="card-header">Account Form</div>
										<div class="card-body">	
											<?php echo form_open()?>
											<table class="table">
												<tr class="text-center">
													<th>
														<div class="form-group">
															<label>Date From</label>
															<input type="date" name="date1" value="<?php if(!empty($_POST['date1'])){ echo $_POST['date1'];}?>" class="col-md-5 form-control">
														</div>
													</th>													
													<th>
														<div class="form-group">
															<label>Date To</label>
															<input type="date" name="date2" value="<?php if(!empty($_POST['date2'])){ echo $_POST['date2'];}?>" class="col-md-5 form-control">
														</div>
													</th>
													
												</tr>
												<tr>
													<td>
														<div class="form-group">
															<label>Test</label>
															<select name="test" class="form-control">
															<?php 
																if(isset($_POST['test']) && $_POST['test']!=0){
																	$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '".$_POST['test']."' ");
																	$result = $query->result();
																	foreach($result AS $row){
																	echo "<option value='{$row->test_id}'>{$row->test_name}</option>";
																	}


																	$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` != '".$_POST['test']."'");
																	$result = $query->result();
																	foreach($result AS $row){
																	echo "<option value='{$row->test_id}'>{$row->test_name}</option>";
																	}

																echo "<option value='0'>Please Select...</option>";	


																}else{
																	echo "<option value='0'>Please Select...</option>";	
																	$query = $this->db->query("SELECT * FROM `tests`");
																	$result = $query->result();
																	foreach($result AS $row){
																	echo "<option value='{$row->test_id}'>{$row->test_name}</option>";
																	}
																}

																
															?>
															</select>
														</div>
													</td>
													<td>
														<div class="form-group">
															<label>Doctor</label>
															<select name="doc" class="form-control">
															
															<?php 
																if(isset($_POST['doc']) && $_POST['doc']!=0){

																	$query = $this->db->query("SELECT * FROM `doctors` WHERE `doc_id` = '".$_POST['doc']."' ");
																	$result = $query->result();
																	foreach($result AS $row){
																	echo "<option value='{$row->doc_id}'>{$row->doc_name}</option>";
																	}

																	$query = $this->db->query("SELECT * FROM `doctors` WHERE `doc_id` != '".$_POST['doc']."' ");
																	$result = $query->result();
																	foreach($result AS $row){
																	echo "<option value='{$row->doc_id}'>{$row->doc_name}</option>";
																	}

																echo "<option value='0'>Please Select...</option>";	

																}else{
																echo "<option value='0'>Please Select...</option>";	
																$query = $this->db->get('doctors');
																$result = $query->result();
																foreach($result AS $row){
																	echo "<option value='{$row->doc_id}'>{$row->doc_name}</option>";
																}
																}

															?>
															</select>
														</div>
													</td>
												</tr>
												<tr>
													<td colspan="2">

													<div class="form-group">
														<label>Invoice No</label>
														<input type="text" name="inv" class="col-md-4 form-control" placeholder="invoice number " value="<?php if(isset($_POST['inv'])){ echo $_POST['inv']; }?>">
													</div>
													</td>
												</tr>
												<tr>
													<th colspan="2">
														<button class="btn btn-success" name="submit" type="submit">Submit</button>
													</th>
												</tr>
											</table>
											<?php echo form_close()?>
										</div>
									</div>
								</div>
						</div>	



						<?php }
							if(isset($_POST['submit'])){
								$date1 = $this->input->post('date1');
								$date2 = $this->input->post('date2');
								$doc = $this->input->post('doc');
								$test = $this->input->post('test');
								$inv  = $this->input->post('inv');
								$sql = "SELECT * FROM `test_inv` ";
						?>
						<div class="row">
								<div class="col-md-12">
									<div class="card top-blue-bdr">
										<div class="card-header">Accounts  Details</div>
										<div class="card-body">	
											<table class="table table-bordered table-responsive">
												<thead>
													<tr>
														<th>Date</th>
														<th>Patient name</th>
														<th>Doctor Name</th>
														<th>Test Name</th>
														<th>Doc.Per</th>
														<th>Dia.Per</th>
														<th>Doc.Rec</th>
														<th>Dia.Rec</th>
														<th>Total</th>
													</tr>
												</thead>

				<tbody>
		<?php
							
			if(!empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']==0 && $_POST['test']==0)
			{
				$sql.= "WHERE `date` = '$date1' ORDER BY `inv_id` DESC";
			}
			elseif(empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['doc']==0 && $_POST['test']==0 )
			{
				$sql.= "WHERE `date` = '$date2' ORDER BY `inv_id` DESC";
			}elseif(!empty($_POST['date2']) && !empty($_POST['date1']) && $_POST['doc']==0  && $_POST['test']==0 )
			{
				$sql.="WHERE `date` BETWEEN '$date1' AND '$date2' ORDER BY `inv_id` DESC";
			}
			elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']==0 )
			{
				$sql.="WHERE `date` BETWEEN '$date1' AND '$date2' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC";
			}
			elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']==0 )
			{
				$sql.="WHERE `date` BETWEEN '$date1' AND '$date2' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC";//ok
			}

			elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['doc']==0  && $_POST['test']!=0 )
			{
				$sql.="WHERE `date` BETWEEN '$date1' AND '$date2' AND `test` = '$test' ORDER BY `inv_id` DESC";//ok
			}
			elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']!=0 )
			{
				$sql.="WHERE `date` BETWEEN '$date1' AND '$date2' AND `test_id` = '$test' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC";//ok
			}
			elseif(!empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']==0 )
			{
				$sql.="WHERE `date` = '$date1' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC"; //ok
			}
			elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']!=0 )
			{
				$sql.="WHERE  `test_id` = '$test' AND `doc_code` = '$doc'  ORDER BY `inv_id` DESC";//ok
			}
			elseif(empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']!=0 )
			{
				$sql.="WHERE  `date` = '$date2' AND `test_id` = '$test' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC";//ok
			}
			elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']!=0 )
			{
				$sql.="WHERE  `test_id` = '$test' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC"; //ok
			}
			elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']==0)
			{
				$sql.="WHERE  `doc_code` = '$doc' ORDER BY `inv_id` DESC"; //ok
			}
			elseif(!empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']==0  && $_POST['test']!=0)
			{
				$sql.="WHERE `date` = '$date1' AND `test_id` = '$test' ORDER BY `inv_id` DESC"; //ok
			}
			elseif(!empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']!=0  && $_POST['test']!=0)
			{
				$sql.="WHERE `date` = '$date1' AND `test_id` = '$test' AND `doc_code` = '$doc' ORDER BY `inv_id` DESC"; //ok
			}
			elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['doc']==0  && $_POST['test']!=0)
			{
				$sql.="WHERE `test_id` = '$test'  ORDER BY `inv_id` DESC"; //ok
			}

			elseif(isset($_POST['inv'])){
				$sql.="WHERE `inv_no` = '$inv' ";
			}

			
						$totalDoc =0;
						$totaldai_fee =0;
						$total =0;
						$query = $this->db->query($sql);
						$result = $query->result();
						foreach($result AS $row){

							@$total+=$row->recieved;
							@$totalDoc+= $row->doc_fee;
							@$totaldai_fee+= $row->dai_fee;
					?>
																<tr>
																	<td><?php echo date("d-M-Y",strtotime($row->date))?></td>
																	<td>
																		<?php
																			$pat = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$row->pat_code' ");
																			if($pat->num_rows()==1){
																				echo $pat->row(0)->patien_name;
																			}
																		?>
																	</td>
																	<td>
																		<?php
																			if($row->referrar == 1){
																				$doc = $this->db->query("SELECT * FROM `doctors` WHERE `doc_id` = '$row->doc_code' ");
																				if($doc->num_rows()==1){
																					echo $doc->row(0)->doc_name." (".$doc->row(0)->hos_name.")";
																				}
																			}
																		?>
																	</td>
																	<td>
																		<?php
																			$test = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$row->test_id' ");
																			if($test->num_rows()==1){
																				echo $test->row(0)->test_name;
																			}
																		?>
																	</td>
																	<td><?php echo $row->doc_per?>(<?php echo $row->d_i_per?>)</td>
																	<td><?php echo $row->dai_per?>(<?php echo $row->dia_i_per?>)</td>
																	<td><?php echo $row->doc_fee?></td>
																	<td><?php echo $row->dai_fee?></td>
																	<td><?php echo $row->recieved?></td>
																</tr>
															<?php }if($total>=0){?>

																<tr>
																	<th colspan="6">Total</th>
																	
																	<th class="text-center"><?php echo $totalDoc;?><hr><hr></th>
																	<th class="text-center"><?php echo $totaldai_fee?><hr><hr></th>
																	<th class="text-center"><?php echo $total?><hr><hr></th>
																</tr>

															<?php }?>

														</tbody>
												</table>
										</div>
									</div>
								</div>
							</div>

						<?php }?>
					</div>
						

</div>