<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Welcome to Unify Admin Template</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login"></span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">
							<div class="card top-blue-bdr">
									<div class="card-header">Change Password</div>
										<div class="card-body">	
											<table class="table table-hover table-responsive">
												<?php
													$id = $this->session->userdata('user_id');
													$query= $this->db->query("SELECT * FROM `users` WHERE `user_id` =  '$id' ");
													$result =$query->result();
													foreach($result AS $row){

												?>
												<tr>
													<td>Name:</td>
													<td><?php echo $row->name?></td>
												</tr>

												<tr>
													<td>Username:</td>
													<td><?php echo $row->username?></td>
												</tr>

												<tr>
													<td>Email:</td>
													<td><?php echo $row->email?></td>
												</tr>

												<tr>
													<td>Role:</td>
													<td>
														<?php
															if($row->role==1){
																echo "Super Admin";
															}elseif($row->role==2){
																echo "Receptionist";
															}elseif($row->role==0){
																echo "Root";
															}
															
															elseif($row->role==3){
																echo "Test Reporter";
															}
															elseif($row->role==5){
																echo "Account";
															}
														?>
													</td>
												</tr>
												<?php }?>
											</table>
										</div>
									</div>
							</div>
						</div>
					</div>

</div>