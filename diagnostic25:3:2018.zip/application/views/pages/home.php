<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Dashboard</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login">Last Login: 2 hours ago</span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">


							<div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
								<div class="card">
									<div class="card-body">
										<a href="<?php echo base_url()?>dashboard/all-doctors">
										<div class="stats-widget">
											<div class="stats-widget-header">
												<i class="icon-users"></i>
											</div>
											<div class="stats-widget-body">
												<!-- Row start -->
												<ul class="row no-gutters">
													<li class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col">
														<h6 class="title">Doctors</h6>
													</li>
													<li class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col">
														<h4 class="total"><?php
															$doc = $this->db->query("SELECT * FROM `doctors` ");
															echo $doc->num_rows();
														?></h4>
													</li>
												</ul>
											</div>
										</div>
										</a>
									</div>
								</div>
							</div>

								<div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
									<div class="card">
										<div class="card-body">
											<a href="<?php echo base_url()?>dashboard/all-tests">
											<div class="stats-widget">
												<div class="stats-widget-header">
													<i class="icon-document3"></i>
												</div>
												<div class="stats-widget-body">
													<!-- Row start -->
													<ul class="row no-gutters">
														<li class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col">
															<h6 class="title">Test</h6>
														</li>
														<li class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col">
															<h4 class="total"><?php
																$test = $this->db->query("SELECT * FROM `tests` ");
																echo $test->num_rows();
															?></h4>
														</li>
													</ul>
												</div>
											</div>
										</a>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
									<div class="card">
										<div class="card-body">
											<a href="<?php echo base_url()?>dashboard/all-patients">
												<div class="stats-widget">
													<div class="stats-widget-header">
														<i class="icon-users"></i>
													</div>
													<div class="stats-widget-body">
														<!-- Row start -->
														<ul class="row no-gutters">
															<li class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col">
																<h6 class="title">Patients</h6>
															</li>
															<li class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col">
																<h4 class="total"><?php
																	$test = $this->db->query("SELECT * FROM `patient` ");
																	echo $test->num_rows();
																?></h4>
															</li>
														</ul>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>


					</div>

					<div class="row">
						<div class="col-md-12">
						<div class="card">
									<div class="card-header">Tasks</div>
									<div class="card-body">
										
										<div class="row gutters">
											<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col">
												<?php
													$query = $this->db->query("SELECT * FROM `test_inv` WHERE `action` = 0");
													if($query->num_rows()>=0){
												?>

												<div class="info-stats">
													<span class="info-label"></span>
													<h6 class="info-title">Total Pending</h6>
													<h4 class="info-total"><?php echo $query->num_rows()?></h4>
												</div>
												<?php }?>

											</div>
											<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col">
												<?php
													$date = date("Y-m-d");
													$query = $this->db->query("SELECT * FROM `test_inv` WHERE `date` = '$date' AND `action` = 0");
													if($query->num_rows()>=0){

												?>
												<div class="info-stats">
													<span class="info-label red"></span>
													<h6 class="info-title">Todays Panding</h6>
													<h4 class="info-total"><?php echo $query->num_rows()?></h4>
												</div>

												<?php }?>
											</div>
											<?php
													$date = date("Y-m-d");
													$query = $this->db->query("SELECT * FROM `test_inv` WHERE `date` = '$date' AND `action` = 1");
													if($query->num_rows()>=0){

												?>
											<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col">
												<div class="info-stats">
													<span class="info-label green"></span>
													<h6 class="info-title">Todays Complete</h6>
													<h4 class="info-total"><?php echo $query->num_rows()?></h4>
												</div>
											</div>

											<?php }?>
										</div>
									</div>
								</div>
						</div>

					</div>	
	</div>
</div>
