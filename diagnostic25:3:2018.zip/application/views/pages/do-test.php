<?php
	if(isset($_POST['make_inv'])){
		$inv = $_POST['inv'];
		$pid = $_POST['pid'];
		$total = $_POST['total'];
		$payment = $_POST['payment'];
		$due = $_POST['due'];

		$attr = array(
			"date" => date("Y-m-d"),
			"inv_no " => $inv,
			"patient_id" => $pid,
			"Recieve" => $total,
			"paied"	  => $payment,
			"due"	  => $due		

		);
	
		if($this->db->insert("ladger",$attr) == TRUE ){

			redirect('dashboard/do-test?inv='.$inv.'&pid='.$pid.'&action=success','refresh');			
			
		}



	}
if(isset($_GET['action']) && $_GET['action']=='success'){
	
		echo "
				<div class='modal hide fade top-margin' id='myModal'>
                        <div class='card top'>
                        <div class='card-header'>New Request Form                        	
                             <button type='button' class='close' data-dismiss='modal'>&times;</button>
                        </div>
                            <div class='card-body '>
								<p> Payment Success </p>

								<a class='btn btn-success btn-lg' target='_blank' href='".base_url()."print-invoice?pid=".$_GET['pid']."&inv=".$_GET['inv']."'>print Invoice</a>
                            </div>
                        </div>

                </div>
			";
}

?>

<div class="app-main">
					<!-- BEGIN .main-heading -->
				<header class="main-heading">
					<div class="container-fluid">
						<div class="row">
							<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
								<div class="page-icon">
									<i class="icon-laptop_windows"></i>
								</div>
								<div class="page-title">
									<h5>Dashboard</h5>
									<h6 class="sub-heading"></h6>
								</div>
							</div>
							<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
								<div class="right-actions">
									<span class="last-login">Test</span>
								</div>
							</div>
						</div>
					</div>
				</header>
				<?php
					/***********************
							Remove Entry
					************************/
					if(isset($_GET['delete'])){
						$delete = $this->db->query("DELETE FROM `test_inv` WHERE `inv_id` = '".$_GET['delete']."' ");
					}
				?>

				<div class="main-content">
					<?php
						if(isset($_POST['submit'])){
							$pid = $this->input->post('pid');
							$inv = $this->input->post('inv');
							$doc = $this->input->post('doc');
							$test = $this->input->post('test');
							

							$disDia = $this->input->post('disDia');
							$disDoa = $this->input->post('disDoa');

							$docRecieve = $this->input->post('docRecieve');
							$DiaRecieve = $this->input->post('DiaRecieve');
							
							$payable = $this->input->post('payable');
							
							$fcost = $this->input->post('fcost');
							$diagnostic = $this->input->post('dpercent');
							$dopercent = $this->input->post('dopercent');
							
							$date = date("Y-m-d");
							$referrar = 1;

							$attr = array(
								"inv_no"		=> $inv,
								"test_id"		=> $test,
								"pat_code"		=> $pid,
								"doc_code"		=> $doc,
								"referrar"		=> $referrar,
								"test_fee"		=> $fcost,
								"doc_per"		=> $disDoa,
								"dai_per"		=> $disDia,
								
								"d_i_per"		=> $dopercent,
								"dia_i_per"		=> $diagnostic,
								"date"			=> $date,

								"doc_fee"	=> $docRecieve,
								"dai_fee"		=> $DiaRecieve,
								"recieved"		=> $payable
							);

							if($disDia > $diagnostic || $disDoa > $dopercent){
								echo "<div class='row'><div class='col-md-12'><div class='alert bg-warning font-white'>Percentage Error</div></div></div>";
							}else{

								if($this->db->insert('test_inv',$attr)==TRUE){
									echo "<div class='row'><div class='col-md-12'><div class='alert bg-success font-white'>
										Test Added
									</div></div></div>";
								}else{
									echo "<div class='row'><div class='col-md-12'><div class='alert bg-danger font-white'>
										Error!!
									</div></div></div>";
								}
							}
						}
					?>
					<div class="row">
							<div class="col-md-4">
								<div class="card top-blue-bdr">
									<div class="card-header">Patient  Details</div>
										<div class="card-body">										
											<!-- Patient Details -->
											<?php
												$patient_code = $this->input->get('pid');
												$query = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$patient_code' ");
												$result = $query->result();
												foreach($result AS $row){
											?>											
												<div class="userdetails">
													<p><b>Patient Name:</b> <?php echo $row->patien_name?></p>
													<p><b>contact:</b> <?php echo $row->contact?></p>
													<p><b>Gender:</b> <?php if($row->gender==1){ echo "Male";}else{ echo "Female"; }?></p>
													<p><b>Address:</b> <?php echo $row->address;?></p>
												</div>
											<?php }?>
											<!-- Patient Details End-->
											<div class="test-details">
												<?php echo form_open("dashboard/do-test?inv=".$_GET['inv']."&pid=".$_GET['pid'])?>
													<input type="hidden" name="pid" value="<?php echo $_GET['pid']?>">
													<input type="hidden" name="inv" value="<?php echo $_GET['inv']?>">
													

													<div class="form-group">
														<?php
															if(isset($_POST['submit'])){
														?>

														<label>Doctor </label>
														<select  name="doc"  onchange="CalculateDiscount()" class="form-control ">
																<?php
																	$query = $this->db->query("SELECT * FROM `doctors` WHERE `doc_id` = '".$_POST['doc']."'");
																	$result = $query->result();
																	foreach($result AS $row){
																?>
																<option value="<?php echo $row->doc_id?>"><?php echo $row->doc_name?> (<?php echo $row->spe?> ) </option>
																<?php }?>

																<?php
																	$query = $this->db->query("SELECT * FROM `doctors` WHERE `doc_id` != '".$_POST['doc']."'");
																	$result = $query->result();
																	foreach($result AS $row){
																?>
																<option value="<?php echo $row->doc_id?>"><?php echo $row->doc_name?> (<?php echo $row->spe?>)</option>
																<?php }?>

														</select>
														<?php }else{?>
														
														<label>Doctor </label>
														<select  name="doc"  onchange="CalculateDiscount()" class="form-control ">
																<option value="">Please Select...</option>
																<?php
																	$query = $this->db->get('doctors');
																	$result = $query->result();
																	foreach($result AS $row){
																?>
																<option value="<?php echo $row->doc_id?>"><?php echo $row->doc_name?> (<?php echo $row->spe?>)</option>
																<?php }?>
														</select>

														<?php }?>
													</div>

													<div class="form-group">
														<label>Test</label>
														<select onchange='TestPrice(this.value)' name="test" class="form-control ">
																<option value="">Please Select...</option>
																<?php
																	$query = $this->db->get('tests');
																	$result = $query->result();
																	foreach($result AS $row){
																?>
																<option value="<?php echo $row->test_id?>"><?php echo $row->test_name?></option>
																<?php }?>
														</select>

													</div>

													<div id="showForm">

													</div>
													
													<div class="form-group">
														<label>Discount by diagnostic (in %)</label>
														<input onkeyup="CalculateDiscount()" type="number" class="form-control" name="disDia" id="disDia" value="0">
													</div>

													<div class="form-group">
														<label>Discount by Doctor (in %)</label>
														<input type="number" class="form-control" onkeyup="CalculateDiscount()" name="disDoa" id="disDoa" value="0">
													</div>
													
													<div class="form-group">
														<label>diagnostic Recieve</label>
														<input type="text" class="form-control"  name="DiaRecieve"  id="DiaRecieve" value="0">
													</div>
													

													<div class="form-group">
														<label>Doctor Recieve</label>
														<input type="text" class="form-control" name="docRecieve" id="docRecieve" value="0">
													</div>

													

													<div class="form-group">
														<label>Payable</label>
														<input type="text" name="payable" id="payable" class="form-control">
													</div>												


													<div class="form-group">
														<button name="submit" class="btn btn-success" type="submit">Add</button>
													</div>
												<?php echo form_close()?>
											</div>
										</div>
								</div>
							</div>

							<div class="col-md-8">
									<div class="card top-blue-bdr">
										<div class="card-header">
											
											<!--<a target="_blank" href="<?php echo base_url()?>=<?php echo $_GET['inv']?>&pid=<?php echo $_GET['pid']?>" class=""> Print Invoice</a>-->

											<a target="_blank" href="<?php echo base_url()?>save-invoice?inv=<?php echo $_GET['inv']?>&pid=<?php echo $_GET['pid']?>" class="btn btn-outline-light btn-rounded btn-sm"><i class="icon-download"></i>Preview</a>
										</div>
										<div class="card-body">	
											<?php  echo form_open()?>
												<table class="table table-bordered table-responsive">
													<thead>
														<tr>
															<th width="10">S/N</th>
															<th>Test Name</th>
															<th width="30">Doctor(%)</th>
															<th width="30">Diagnotics(%)</th>
															
															<th width="10">Doctor</th>
															<th width="10">Diagnostic</th>
															<th width="10">Total</th>
															<th>Remove</th>
														</tr>
														</thead>
														<tbody>

														<?php
																$total=0;
																$totalDoc=0;
																$totaldai_fee=0;
															$inv = $this->input->get('inv');
															$query = $this->db->query("SELECT * FROM `test_inv` WHERE `inv_no` = '$inv' ");

															$result = $query->result();
															foreach($result AS $row){
																@$sl++;
																$total+=$row->recieved;
																$totalDoc+= $row->doc_fee;
																$totaldai_fee+= $row->dai_fee;
														?>
															<tr>
																<td><?php echo $sl?></td>
																<td>
																	<?php
																		$test = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$row->test_id' ");
																		if($test->num_rows()==1){
																			echo $test->row(0)->test_name;
																		}
																	?>																	
																</td>
																
																<td><?php echo $row->doc_per?> %  &nbsp - &nbsp (<?php echo $row->d_i_per?>%)</td>
																<td><?php echo $row->dai_per?> % &nbsp - &nbsp  (<?php echo $row->dia_i_per?>%)</td>
																<td><?php echo $row->doc_fee?></td>
																<td><?php echo $row->dai_fee?></td>
																<td><?php echo $row->recieved?></td>
																<th width="4"> <a href="<?php echo base_url()?>dashboard/do-test?inv=<?php echo $_GET['inv']?>&pid=<?php echo $_GET['pid']?>&delete=<?php echo $row->inv_id?>"><i class="fa fa-trash"></i></a></th>
															</tr>

														<?php } if($total >0){?>
															<tr>
																<th colspan="4">Total</th>
																<th width="30"><?php echo $totalDoc;?></th>
																<th width="30"><?php echo $totaldai_fee;?></th>
																<th width="40"><?php echo $total;?></th>
																<input type="hidden" id="total" name="total" value="<?php echo $total;?>">
															</tr>

															<tr>
																<td></td>
																<td>
																<div class="form-group">
																	<label>payment</label>
																		<input required="" type="text" oninput="getDue()" class="form-control" name="payment" id="payment">
																</div>
																</td>

																<td>
																	<div class="form-group">
																		<label>Due</label>
																			<input type="text" disabled="disabled" class="form-control" id="due">
																			<input type="hidden"  class="form-control" name="due" id="due2">

																			<input type="hidden" name="inv" value="<?php echo $_GET['inv']?>">
																			<input type="hidden" name="pid" value="<?php echo $_GET['pid']?>">
																	</div>
																</td>
																<td>
																	<button class="btn btn-outline-light btn-rounded btn-sm" name="make_inv" id="save"> Save & <i class="icon-print2"></i> Print</button>
																</td>
															</tr>
														<?php }?>
														</tbody>
															
													
												</table>
												<?php echo form_close()?>
										</div>
									</div>
							</div>
					</div>
				</div>

</div>

<script type="text/javascript">
	//Get Test Price
	function TestPrice(str){
		  var xhttp;
		  if (str == "") {
		    document.getElementById("showForm").innerHTML = "";
		    return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (this.readyState == 4 && this.status == 200) {
		    	document.getElementById("showForm").innerHTML = this.responseText;
		    	CalculateDiscount();
		    	
		    }
		  };
		  xhttp.open("GET", "<?php echo base_url()?>Dashboard/getTestprice/"+str, true);
		  xhttp.send();
	}
//Calculate Price
	function CalculateDiscount(){

		var fullcost = document.getElementById("fcost").value;
		var disDia = document.getElementById("disDia").value;
		var disDoa = document.getElementById("disDoa").value;

		var docDis = document.getElementById("doctor").value;
		var diaG = document.getElementById("diagnostic").value;

		var Finmath = document.getElementById("docRecieve").value;

		//Doctor Recieve
		var finalDocDis = docDis-disDoa;
		var docPerPrice = (fullcost*finalDocDis)/100;
	 	document.getElementById("docRecieve").value=docPerPrice;
	 	

	 	//Diagnoist Recieve 
	 	var finalDiagDis = diaG-disDia;
		var digPerPrice = (fullcost*finalDiagDis)/100;
	 	document.getElementById("DiaRecieve").value=digPerPrice;

	 	//Final Price Total Discount
	 	var finalPrice = digPerPrice+docPerPrice;
	 	document.getElementById("payable").value=finalPrice;


	 	//

	}

	function getDue(){
		var total = document.getElementById("total").value;
		var payment = document.getElementById("payment").value;
		
		var due = total-payment;
		document.getElementById("due").value=due;
		document.getElementById("due2").value=due;


		if(document.getElementById("due").value < 0){
			alert("abnormal Value");
			document.getElementById("save").disabled=true;
		}else{
			document.getElementById("save").disabled=false;
		}
	}
</script>

