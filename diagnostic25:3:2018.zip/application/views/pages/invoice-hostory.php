<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Invoice History</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login">Last Login: 2 hours ago</span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">
								<div class="col-md-12">
									<div class="card top-blue-bdr">
									<div class="card-header">Search History</div>
										<div class="card-body">	
										<?php echo form_open()?>
											<table class="table table-bordered table-responsive">
												<thead>
												<tr>
													<td>
														<div class="form-group">
															<label>Date To</label>
															<input type="date" name="date1" class="form-control">
														</div>
													</td>												
													<td>
														<div class="form-group">
															<label>Date From</label>
															<input type="date" name="date2" class="form-control">
														</div>
													</td>
													<td>
														<div class="form-group">
															<label>Invoice</label>
															<input type="text" name="inv" class="form-control">
														</div>
													</td>
												</tr>
											<tr>
												<td colspan="3">
													<div class="form-group mypadding-top">
														<button class="btn btn-success" name="submit" type="submit"> Submit </button>
													</div>
												</td>
											</tr>

												</thead>
											</table>
										<?php echo form_close()?>
										</div>
									</div>
								</div>
						</div>
				<?php
					if(isset($_POST['submit'])){
						$date1 = $this->input->post('date1');
						$date2 = $this->input->post('date2');
						$inv = $_POST['inv'];
						$sql = "SELECT * FROM `ladger` ";
				?>
						<div class="row">
								<div class="col-md-12">
									<div class="card top-blue-bdr">
									<div class="card-header">Histories of <?php echo $date1?> To <?php echo $date2?></div>
										<div class="card-body">	
												<table class="table table-bordered table-responsive">
													<thead>
														<tr>
															<th>Date</th>
															<th>Details</th>
															<th>Invoice No</th>
															<th>Total</th>
															<th>Paied</th>
															<th>Due</th>
															<th>Action</th>																
														</tr>
													</thead>
													<tbody>
													<?php
														if(isset($_POST['inv']) && empty($_POST['date1']) && empty($_POST['date1']) ){
															$sql.=" WHERE `inv_no` = '$inv' "; 
														}
														elseif(!empty($_POST['date1']) && empty($_POST['date2'])){
														$sql.= "WHERE `date` = '$date1' ORDER BY `lad_id` ASC";
														}elseif(empty($_POST['date1']) && !empty($_POST['date1'])){
														$sql.= "WHERE `date` = '$date2' ORDER BY `lad_id` ASC";
														}elseif(!empty($_POST['date2']) && !empty($_POST['date1']) ){
														$sql.="WHERE `date` BETWEEN '$date1' AND '$date2' ORDER BY `lad_id` ASC";
														}elseif(empty($_POST['date1']) && empty($_POST['date1'])){

														}												

														$query = $this->db->query($sql);
														$result = $query->result();
														foreach($result AS $row){

													?>

														<tr>
															<td><?php echo $row->date?></td>
															<td>Payment Recieved</td>
															<td><a target="_blank" href="<?php echo base_url()?>print-invoice?inv=<?php echo $row->inv_no?>&pid=<?php echo $row->patient_id?>"><?php echo $row->inv_no;?></a></td>
															<td><?php echo $row->Recieve?></td>
															<td><?php echo $row->paied?></td>
															<td><?php echo $row->due?></td>
															<td>
																<?php if($row->due <= 0){?>
																<a class='btn btn-outline-light btn-rounded btn-sm' href="<?php echo base_url()?>print-invoice?inv=<?php echo $row->inv_no?>&pid=<?php echo $row->patient_id?>">view</a>
																<?php }else{?>
																<a target='_blank' class='btn btn-sm btn-success' href="<?php echo base_url()?>dashboard/pay-due/<?php echo $row->inv_no?>">Pay due</a>
																<?php }?>

															</td>
														</tr>

														<?php }?>
													</tbody>
												</table>


										</div>
									</div>
								</div>
						</div>
				<?php }?>
					</div>

</div>