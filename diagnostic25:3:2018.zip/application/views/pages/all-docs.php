<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Welcome to Unify Admin Template</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login">Last Login: 2 hours ago</span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">
							<div class="col-md-12">
							<div class="card">
										<div class="card-header">Doctors</div>											
										<div class="card-body">
											<table class="table table-bordered table-responsive">
									<thead>
										<tr>											
											<th>Doctor Name</th>
											<th>Hospital name</th>
											<th>Digree</th>
											<th>Specialis</th>											
										</tr>
									</thead>
									  <tbody>
									  	<?php
									  		$query = $this->db->get("doctors");
									  		$result = $query->result();
									  		foreach($result AS $row){
									  	?>
										<tr>											
											<td><?php echo $row->doc_name?></td>
											<td><?php echo $row->hos_name?></td>
											<td><?php echo $row->deg?></td>
											<td><?php echo $row->spe?></td>
											
										</tr>
										<?php }?>
									</tbody>
							</table>
										</div>
									</div>
								</div>
						</div>
					</div>

</div>