<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Due Payment</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login"></span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
								<?php
									if(isset($_POST['payment'])){
										$inv= $_POST['inv'];
										$paied= $_POST['paied'];
										$due= $_POST['due'];
										$amount= $_POST['amount'];

										if($amount > $due){
											echo "<Div class='row'><Div class='col-md-12'><Div class='alert bg-warning'> Abnormal Entry..  </div></div></div>";
										}else{

											$fpaid = $paied+$amount;
											$fdue = $due-$amount;
											$attr = array(
												"paied" =>$fpaid,
												"due "	=> $fdue
											);

											$this->db->where('inv_no',$inv);
											if($this->db->update('ladger',$attr)==TRUE){
												echo "<Div class='row'><Div class='col-md-12'><Div class='alert bg-success'>Due Paid Successfully</div></div></div>";
											}else{
												echo "<Div class='row'><Div class='col-md-12'><Div class='alert bg-danger'> There is something Wrong. Please Check Details </div></div></div>";
											}

										}

									}
								?>

						<div class="row">
							<div class="col-md-5">
								<div class="card">
											<div class="card-header">Payment Details</div>											
											<div class="card-body">
												<?php echo form_open()?>
													<?php
														$inv =$this->uri->segment(3);
														$query = $this->db->query("SELECT * FROM `ladger` WHERE `inv_no` = '$inv'  ");
														$result = $query->result();
														foreach($result AS $row){
													?>

															<div class="form-group">
																<label>Total Amount</label>
																<input type="text" class="form-control" value="<?php echo $row->Recieve?>" disabled="" name="">
																<input type="hidden" class="form-control" value="<?php echo $row->Recieve?>"  name="total">
															</div>
															<?php echo form_hidden('inv',$row->inv_no)?>
															<div class="form-group">
																<label>Paied</label>
																<input type="text" class="form-control" value="<?php echo $row->paied?>" disabled="" name="">
																<input type="hidden" class="form-control" value="<?php echo $row->paied?>"  name="paied">
															</div>

															<div class="form-group">
																<label>Due</label>
																<input type="text" class="form-control" value="<?php echo $row->due?>" disabled="" name="">
																<input type="hidden" class="form-control" value="<?php echo $row->due?>"  name="due">
															</div>
													<?php }?>
															

													<div class="form-group">
														<label>Amount</label>
														<input type="text" required="required" class="form-control" value=""  name="amount">
													</div>

													<div class="form-group">

														<button name="payment" type="submit" class="btn btn-sm"> payment </button>
													</div>
															
												<?php echo form_close()?>
											</div>

										</div>

								</div>
							</div>
						</div>
					</div>

</div>