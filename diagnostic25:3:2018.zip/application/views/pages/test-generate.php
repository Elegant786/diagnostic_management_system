<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Welcome to Unify Admin Template</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login">Last Login: 2 hours ago</span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">
									<?php
										error_reporting(0);
										if(isset($_POST['submit'])){
											$count = count($_POST['atrid']);
											$pid = $_POST['pid'];
											$test = $_POST['test'];
											$re_id = $_POST['re_id'];
											$inv = $_POST['inv'];
											
											$query = $this->db->query("SELECT * FROM `test_report` WHERE `rep_no` = '$re_id'  ");
											if($query->num_rows()==0){
												for($i=0;$i<$count;$i++){
													$attr = array(
														"patien_id"		=>$pid,
														"attr_id"		=> $_POST['atrid'][$i],
														"attr_result"	=> $_POST['result'][$i],
														"test_id"		=> $test,
														"rep_no"		=> $re_id,
														"date"			=> date("Y-m-d")
													);
													$this->db->insert('test_report',$attr);

													$this->db->query("UPDATE `test_inv` SET `action` = 1 WHERE `inv_no` = '$inv' AND `test_id`  = '$test' ");
												}
											}


										}
									?>

							<div class="col-md-4">
									<div class="card top-blue-bdr">
										<div class="card-header">Generate Test</div>
											<div class="card-body">
												<?php echo form_open()?>
													<input name="pid" type="hidden" value="<?php echo $this->uri->segment(3)?>">
													<input name="test" type="hidden" value="<?php echo $this->uri->segment(4)?>">
													<input name="re_id" type="hidden" value="<?php echo $this->uri->segment(5)?>">
													<input name="inv" type="hidden" value="<?php if(isset($_POST['inv'])){ echo $_POST['inv'] ;} else{ echo $_GET['inv'];}?>">
														<table class="table table-bordered">
																<thead>
																	<tr>
																		<th>name</th>
																		<th>Range</th>
																		<th>Result</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																		$test_id = $this->uri->segment(4);
																		$pcode = $this->uri->segment(3);

																		$query = $this->db->query("SELECT * FROM `test_attr` WHERE `test_id` = '$test_id' ");
																		$result = $query->result();
																		foreach($result AS $row){
																	?>
																	<tr>
																		<td><?php echo $row->attr_name?> <input type="hidden" name="atrid[]" value="<?php echo $row->attr_id?>"></td>
																		<td><?php echo $row->attr_normal?></td>
																		<td><input type="text" class=" form-control" value="" name="result[]"></td>
																	</tr>
																	<?php }?>
																	<tr>
																		<td colspan="3">
																			<button name="submit" class="btn btn-success" type="submit"> Generate </button>
																		</td>
																	</tr>
																</tbody>
														</table>
												<?php echo form_close()?>
											</div>
										</div>
									</div>

									<div class="col-md-5">
										<div class="card top-blue-bdr">
											<div class="card-header">Report</div>
												<div class="card-body">
													<table class="table table-bordered table-responsive">
														<thead>
															<tr>
																
																	<td colspan="3">
																		<a target="_blank" href="<?php echo base_url()?>print-report?pid=<?php echo $this->uri->segment(3)?>&report=<?php echo $this->uri->segment(5)?>&test=<?php echo $this->uri->segment(4)?>" class="btn btn-outline-light btn-rounded btn-sm"> Save & <i class="icon-print2"></i>  Print Report</a>

																		<a target="_blank" href="<?php echo base_url()?>save-report?pid=<?php echo $this->uri->segment(3)?>&report=<?php echo $this->uri->segment(5)?>" class="btn btn-outline-light btn-rounded btn-sm"><i class="icon-print2"></i> Preview Report</a>
																	</td>
																
															</tr>
															<tr>
																<th>Name</th>
																<th>Range</th>
																<th>Result</th>
															</tr>
														</thead>
														<tbody>
														<?php
															$rep_no = $this->uri->segment('5');
															$query = $this->db->query("SELECT * FROM `test_report` WHERE `rep_no` = '$rep_no'  ");
															$result = $query->result();
															foreach($result AS $row){
														?>

															<tr>
																<td>
																	<?php
																		$query = $this->db->query("SELECT * FROM `test_attr` WHERE `attr_id` = '$row->attr_id' ");
																		if($query->num_rows()==1){
																			echo $query->row(0)->attr_name;
																		}
																	?>
																</td>
																<td>
																	<?php echo $row->attr_result?>
																</td>

																<td>
																	<?php
																		$query = $this->db->query("SELECT * FROM `test_attr` WHERE `attr_id` = '$row->attr_id' ");
																		if($query->num_rows()==1){
																			echo $query->row(0)->attr_normal." ".$query->row(0)->unite;
																		}
																	?>
																</td>
																
															</tr>

															<?php }?>
														</tbody>
													</table>
												</div>
										</div>
										
									</div>
						</div>
					</div>

</div>