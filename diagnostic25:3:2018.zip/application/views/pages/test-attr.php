<div class="app-main">
	<!-- BEGIN .main-heading -->
	<header class="main-heading">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
					<div class="page-icon">
						<i class="icon-laptop_windows"></i>
					</div>
					<div class="page-title">
						<h5>Dashboard</h5>
						<h6 class="sub-heading">Test Attribute</h6>
					</div>
				</div>
				<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
					<div class="right-actions">
						<span class="last-login"></span>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div class="main-content">
		<?php
			if(isset($_POST['submit'])){
				
				$test = $this->input->post('test');
				$count = count($_POST['attr']);
				
				for($i=0; $i<$count;$i++){

					$attr = array(
						"attr_name"  	=> $_POST['attr'][$i],
						"attr_normal"	=> $_POST['value'][$i],
						"unite"			=> $_POST['unite'][$i],
						"test_id"		=> $test
					);

					$this->db->insert('test_attr',$attr);

				}
				
			}
		?>

		<div class="row">
			<div class="col-md-4">
				<div class="card top-blue-bdr">
					<div class="card-header">Edit Test</div>
					<div class="card-body">
						<?php echo form_open()?>
							<input type="hidden" name="test" value="<?php echo $this->uri->segment(3)?>">
							<table class="table table-bordered input_fields_wrap">
								<thead>
									<tr>
										<th colspan="3">
											<button class="btn btn-success btn-sm add_field_button">Add more</button>
										</th>
									</tr>
									<tr>
										<td>Name</td>
										<td>Normal Range</td>
										<td>Unite</td>
									</tr>
									<tr>
										<td>
											<div class="form-group">
												<input name="attr[]" required class="form-control" type="text">
											</div>
										</td>
										<td>
											<div class="form-group">
												<input name="value[]" required class="form-control" type="text">
											</div>
										</td>
										<td>
											<div class="form-group">
												<input name="unite[]" required value="--" class="form-control" type="text">
											</div>
										</td>
									</tr>
								</thead>
									<tbody class="here2">
										
									</tbody>
								

								<tfoot>
									<tr>
										<td colspan="3">
											<button type="submit" name="submit" class="btn btn-success">Submit</button>
										</td>
									</tr>
								</tfoot>
							</table>
						<?php echo form_close()?>
						
						
					</div>
					
				</div>
			</div>

			<div class="col-md-4">
				<div class="card top-blue-bdr">
					<div class="card-header">Edit Test</div>
					<div class="card-body">
							<table class="table table-bordered table-responsive">
								<thead>
									<tr>
										<th>Attr name</th>
										<th>Normal Value</th>
										<th>Unite</th>
									</tr>
								</thead>
								<tbody>
									<?php
										$test = $this->uri->segment(3);
										$query = $this->db->query("SELECT * FROM `test_attr` WHERE `test_id` = '$test'  ");
										$result = $query->result();
										foreach($result AS $row){
									?>
									<tr>
										<td><?php echo $row->attr_name?></td>
										<td><?php echo $row->attr_normal?></td>
										<td><?php echo $row->unite?></td>
									</tr>
									<?php }?>
								</tbody>
							</table>
					</div>
				</div>

			</div>
		</div>
	</div>
	
	
</div>