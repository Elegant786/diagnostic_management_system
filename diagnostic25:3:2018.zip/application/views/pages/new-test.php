<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">New Test</h6>
									</div>
								</div>
								
							</div>
						</div>
					</header>
					<?php
						if(isset($_POST['submit'])){
							
							$name = $this->input->post('name');
							$pid = $this->input->post('pid');
							$contact = $this->input->post('contact');
							$gender = $this->input->post('gender');
							$address = $this->input->post('address');
							
							$attr = array(
								"patien_name"	=> $name,
								"patient_code"	=> $pid,
								"gender"		=> $gender,
								"address"	=> $address,
								"contact"	=> $contact
							);
							if($this->db->insert('patient',$attr)==TRUE){
								$count = $this->db->get('test_inv');
								$num = $count->num_rows()+1;
								$inv = date('ymdh').$num;
								redirect('dashboard/do-test?inv='.$inv.'&pid='.$pid,'refresh');

							}else{
								echo "<div class='row'> <div class='col-md-12'> <div class='alert bg-danger text-center font-white'>Please  Check Error</div> </div></div>";
							}
						}
					?>

					<div class="main-content">
						<div class="row">
								<div class="col-md-6 margin-auto">
										<div class="card top-blue-bdr">
											<div class="card-header">Patient  Details</div>
												<div class="card-body">
													<?php echo form_open()?>
												
												<div class="form-group">
													<label>Patient ID</label>
													<input name="pid" value="<?php echo $this->input->get('pid')?>" class="form-control" type="hidden">
													<input name="pid" value="<?php echo $this->input->get('pid')?>" class="form-control" disabled type="text">
												</div>

												<div class="form-group">
													<label>Name</label>
													<input name="name" required class="form-control" type="text">
												</div>

												<div class="form-group">
													<label>Contact</label>
													<input name="contact" required class="form-control" type="text">
												</div>

												<div class="form-group">
													<label>Gender</label><br>
													<input name="gender" required value="1" type="radio"> Male
													<input name="gender" required value="0"  type="radio"> Female
												</div>

												<div class="form-group">
													<label>Address</label>
													<textarea name="address" required rows="9" class="form-control"></textarea>
												</div>

												<div class="form-group">
													<button class="btn btn-success" type="submit" name="submit">Next >></button>
												</div>


													<?php echo form_close()?>	
												</div>
											</div>
										</div>
								</div>
						</div>
					</div>

</div>