<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">User Change Password</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login">Last Login: 2 hours ago</span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">
									<?php
										if(isset($_POST['submit'])){
											$pass = md5("Elegant@2018".$_POST['pass']);
											$cpass = md5("Elegant@2018".$_POST['cpass']);
											if($pass == $cpass){
												$this->db->where('user_id',$this->session->userdata('user_id'));
												if($this->db->update('users',array('password'=>$pass))==TRUE){
													echo "<div class='col-md-12'><div class='alert alert-success'>Password Changed</div></div>";
												}else{
													echo "<div class='col-md-12'><div class='alert alert-warning'>Error Password Not Changed</div></div>";
												}
											}else{
												echo "<div class='col-md-12'><div class='alert alert-danger'>passowrd And Confirm Password Not Match</div></div>";
											}
										}

									?>
							<div class="col-md-4">
								<div class="card top-blue-bdr">
									<div class="card-header">Change Password</div>
										<div class="card-body">	
											<?php echo form_open()?>
												<div class="form-group">
													<label>Password</label>
													<input type="text"  name="pass" class="form-control">
												</div>
												<div class="form-group">
													<label>Confirm Password</label>
													<input type="text"  name="cpass" class="form-control">
												</div>
												<div class="form-group">
													<button name="submit" class="btn btn-sm btn-success" type="submit"> Change Password</button>
												</div>
											<?php echo form_close()?>
										</div>

								</div>

							</div>

						
						</div>
					</div>

</div>