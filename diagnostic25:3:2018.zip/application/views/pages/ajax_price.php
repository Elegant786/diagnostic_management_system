<?php
	foreach($test AS $fee){
?>

<div class="form-group">
	<label>Test Price</label>
	<input type="text" disabled name="fcost" class="form-control" value="<?php echo $fee->test_fee?>">
	<input type="hidden" id="fcost" name="fcost" class="form-control" value="<?php echo $fee->test_fee?>">
</div>

<div class="form-group">
	<label>Diagnostic Percent(in %)</label>
	<input name="dpercent" disabled value="<?php echo $fee->dia_per?>" class="form-control">
	<input name="dpercent" id="diagnostic" type="hidden" value="<?php echo $fee->dia_per?>" class="form-control">
</div>

<div class="form-group">
	<label>Doctor Percent(in %)</label>
	<input name="dpercent" disabled value="<?php echo $fee->doc_per?>" class="form-control">
	<input name="dopercent" id="doctor" type="hidden" value="<?php echo $fee->doc_per?>" class="form-control">
</div>



<?php }?>