<!DOCTYPE html>
<html>
<head>
	<title>Print Invoice</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/css/bootstrap.min.css">
	<link rel="stylesheet"  type="text/css" href="<?php echo base_url()?>assets/css/inv-style.css" media="screen, print">
</head>
<body onload="window.print()">
	
	
	
	<section class="userDetails">

		<?php
			$pid = $this->input->get('pid');
			$query = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$pid'  ");
			$result = $query->result();
			foreach($result AS $row){
		?>
		<table class="Usertable">
			<tr>
				<td> <b>Name:</b> <?php echo $row->patien_name?></td>				
				<td class="text-right">Report No: <?php echo $_GET['report']?> </td>
			</tr>

			<tr>
				<td> <b>Contact:</b> &nbsp<?php echo $row->contact?></td>				
				<td class="text-right">Date:  <?php echo date("d-M-Y")?></td>
			</tr>

			<tr>
				<td colspan="2"> <b>Gender:</b> <?php if($row->gender==1){ echo "Male";}else{ echo "Female"; }?></td>				
				<td class="text-right"></td>
			</tr>

			<tr>
				<td colspan="2"><b>Address:</b> <?php echo $row->address?></td>				
				
			</tr>
		</table>
		<?php }?>

	</section>
	<section>
			<table class="table table-bordered">


				<tr>
					<th width="300">Test Name</th>
					<th>Result</th>
					<th width="300">Normal Range</th>
				</tr>
				
		<?php
			$rep_no = $this->input->get('report');
			$query = $this->db->query("SELECT * FROM `test_report` WHERE `rep_no` = '$rep_no'  ");
			$result = $query->result();
			foreach($result AS $row){
		?>

			<tr>
				<td>
					<?php
						$query = $this->db->query("SELECT * FROM `test_attr` WHERE `attr_id` = '$row->attr_id' ");
						if($query->num_rows()==1){
							echo $query->row(0)->attr_name;
						}
					?>
				</td>
				<td>
					<?php echo $row->attr_result?>
				</td>

				<td>
					<?php
						$query = $this->db->query("SELECT * FROM `test_attr` WHERE `attr_id` = '$row->attr_id' ");
						if($query->num_rows()==1){
							echo $query->row(0)->attr_normal." ".$query->row(0)->unite;
						}
					?>
				</td>
				
			</tr>

			<?php }
				$date = date("Y-m-d");
				$test = $_GET['test'];

				$query = $this->db->query("SELECT * FROM `test_history` WHERE `rep_code` ='$rep_no'  ");
				if($query->num_rows()==0){

					$pid = $this->input->get('pid');
					$this->db->query("INSERT INTO `test_history` (`pid`, `rep_code`,`date`,`test_id`) VALUES ('$pid','$rep_no','$date','$test')  ");
				}


			?>

			</table>
	</section>


<footer class="footerDetails">
	<table class="tablefooter">
		<tr>
			<td class="text-left">
				<div style='margin: auto;'>
					--------------------------<br>
					Patient Signature
				</div>
			</td>
			<td class="text-right">
				<div style='margin: auto;'>
					--------------------------<br>
					Reciver Signature
				</div>
			</td>
		</tr>
	</table>
	
</footer>
</body>
</html>