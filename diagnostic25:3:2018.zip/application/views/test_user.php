								<li class="active selected">
									<a href="<?php echo base_url()?>dashboard" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-dashboard"></i>
										</span>
										<span class="nav-title">Dashboards</span>
									</a>
									
								</li>

								
								<li>
									<a href="<?php echo base_url()?>dashboard/test-report" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Pandding Test</span>
									</a>									
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/test-completes" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Test History</span>
									</a>									
								</li>
								
<!--
								<li>
									<a href="<?php echo base_url()?>dashboard/test-management" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Test Management</span>
									</a>									
								</li>-->