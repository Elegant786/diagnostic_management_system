								<li class="active selected">
									<a href="<?php echo base_url()?>dashboard" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-dashboard"></i>
										</span>
										<span class="nav-title">Dashboards</span>
									</a>
									
								</li>		
						
	
								<li>
									<?php
										$query = $this->db->get('patient');
										if($query->num_rows()>=0){
											$num = $query->num_rows()+1;
											$pid = date("ydmhis").$num;
									?>


									<a href="<?php echo base_url()?>dashboard/new-test?pid=<?php echo $pid?>" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">New test</span>
									</a>
									<?php }?>
								</li> 

								<li>
									<a href="<?php echo base_url()?>dashboard/test-completes" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Test History</span>
									</a>									
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/invoice/history">
										<span class="has-icon">
											<i class="icon-chat_bubble_outline"></i>
										</span>
										<span class="nav-title">Invoice History</span>
									</a>
								</li>