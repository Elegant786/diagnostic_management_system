<!DOCTYPE html>
<html>
<head>
	<title>Print Invoice</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/css/bootstrap.min.css">
	<link rel="stylesheet"  type="text/css" href="<?php echo base_url()?>assets/css/inv-style.css" media="screen, print">
</head>
<body onload="window.print()">
	
	<section class="userDetails">

		<?php
			$pid = $this->input->get('pid');
			$query = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$pid'  ");
			$result = $query->result();
			foreach($result AS $row){
		?>
		<table class="Usertable">
			<tr>
				<td> <b>Name:</b> <?php echo $row->patien_name?></td>				
				<td class="text-right">Invoice: <?php echo $_GET['inv']?> </td>
			</tr>

			<tr>
				<td> <b>Contact:</b> &nbsp<?php echo $row->contact?></td>				
				<td class="text-right">Date:  <?php echo date("d-M-Y")?></td>
			</tr>

			<tr>
				<td colspan="2"> <b>Gender:</b> <?php if($row->gender==1){ echo "Male";}else{ echo "Female"; }?></td>				
				<td class="text-right"></td>
			</tr>

			<tr>
				<td colspan="2"><b>Address:</b> <?php echo $row->address?></td>				
				
			</tr>
		</table>
		<?php }?>

	</section>

	<section class="textDetails">
			<table class="table table-bordered">
				<thead>
					<tr>
						<td width="12">SN</td>
						<td>Description</td>
						<td width="40">Price</td>						
					</tr>
				</thead>

				
					<tbody>

					<?php
							$total=0;
							$totalDoc=0;
							$totaldai_fee=0;
						$inv = $this->input->get('inv');
						$query = $this->db->query("SELECT * FROM `test_inv` WHERE `inv_no` = '$inv' ");

						$result = $query->result();
						foreach($result AS $row){
							@$sl++;
							$total+=$row->recieved;
							
					?>
						<tr>
							<td><?php echo $sl?></td>
							<td>
								<?php
									$test = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$row->test_id' ");
									if($test->num_rows()==1){
										echo $test->row(0)->test_name;
									}
								?>																	
							</td>							
							<td><?php echo $row->recieved?></td>
						</tr>

					<?php } if($total >=0){?>
						<tr>
							<th class="text-right" colspan="2">Total</th>
							<th width="40"><?php echo $total;?></th>
						</tr>
						<?php
							$query = $this->db->query("SELECT * FROM `ladger` WHERE `inv_no` = '$inv' ");
							$result = $query->result();
							foreach($result AS $row){
						?>
						<tr>

							<td colspan="2" class="text-right">Paied</td>
							<td><?php echo $row->paied?></td>
						</tr>

						<tr>

							<td colspan="2" class="text-right"><strong>Due</strong></</td>
							<td><strong><?php echo $row->due?></strong></td>
						</tr>

						<?php }?>
						<tr>
							<td colspan="3">
								Total Amount In Words: <b><?php echo $this->DashboardModel->convert_number($total)?> Taka Only</b>
							</td>
						</tr>
					<?php

	
	 }?>
					</tbody>

					
			</table>
	</section>
	
	<footer class="footerDetails">
		<table class="tablefooter">
			<tr>
				<td class="text-left">	
						<div style='margin: auto;'>
					 	 --------------------------<br>
					  		Patient Signature 
					  	</div>
				</td>
				<td class="text-right">
					<div style='margin: auto;'>
					 	 --------------------------<br>
					  		Reciver Signature 
					 </div>
				</td>
			</tr>
		</table>
	</footer>

	
</body>
</html>