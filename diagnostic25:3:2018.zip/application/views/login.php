<!doctype html>
<html lang="en">
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="Unify Admin Panel" />
		<meta name="keywords" content="Login, Unify Login, Admin, Dashboard, Bootstrap4, Sass, CSS3, HTML5, Responsive Dashboard, Responsive Admin Template, Admin Template, Best Admin Template, Bootstrap Template, Themeforest" />
		<meta name="author" content="Bootstrap Gallery" />
		<link rel="shortcut icon" href="<?php echo base_url()?>assets/img/favicon.jpg" />
		<title>Diagnositc</title>
		
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
		
		<!-- Common CSS -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/fonts/icomoon/icomoon.css" />

		<!-- Mian and Login css -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/css/main.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css" />

	</head>  

	<body class="login-bg">
			
		<div class="container">
			<div class="col-md-12 margin-t-10">
				<?php
					if(validation_errors()){
						echo "<div class='alert bg-danger font-white text-center'>".validation_errors()."</div>";
					}
				?>
			</div>
			<div class="login-screen row align-items-center">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
					<?php echo form_open("UserController/TryLogin")?>
						<div class="login-container">
							<div class="row no-gutters">
								<div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
									<div class="login-box">
<!--
										<a href="#" class="login-logo">
											<img src="<?php echo base_url()?>assets/img/unify.png" alt="Unify Admin Dashboard" />
										</a>
-->
										<div class="input-group">
											<span class="input-group-addon" id="username"><i class="icon-account_circle"></i></span>
											<input type="text" class="form-control" required="required" name="username" placeholder="Username" aria-label="username" aria-describedby="username">
										</div>
										<br>
										<div class="input-group">
											<span class="input-group-addon" id="password"><i class="icon-verified_user"></i></span>
											<input type="password" name="password" required="required" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="password">
										</div>
										<div class="actions clearfix">
											
									  	<button type="submit" class="btn btn-primary">Login</button>
									  </div>
									  
									  
									</div>
								</div>
								<div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
									<div class="login-slider">

									</div>
								</div>
							</div>
						</div>
					<?php echo form_close()?>
				</div>
			</div>
		</div>
		<footer class="main-footer no-bdr fixed-btm">
			<div class="container" id="footer_content">
				Copyright Elegant Technology Limited <?php echo date('Y')?>.
			</div>
		</footer>
		
	</body>
</html>