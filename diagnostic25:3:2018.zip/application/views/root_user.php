<li class="active selected">
									<a href="<?php echo base_url()?>dashboard" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-dashboard"></i>
										</span>
										<span class="nav-title">Dashboards</span>
									</a>
									
								</li>
								
								<li>
									<?php
										$query = $this->db->get('patient');
										if($query->num_rows()>=0){
											$num = $query->num_rows()+1;
											$pid = date("ydmh").$num;
									?>


									<a href="<?php echo base_url()?>dashboard/new-test?pid=<?php echo $pid?>" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">New test</span>
									</a>
									<?php }?>
								</li>
								

								<li>
									<a href="<?php echo base_url()?>dashboard/new-doctor" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-users"></i>
										</span>
										<span class="nav-title">Doctor Management</span>
									</a>									
								</li>
								
								<li class="menu-header">
									--  Test menus
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/test-report" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Pandding Test</span>
									</a>									
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/test-management" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Test Management</span>
									</a>									
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/test-completes" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Test History</span>
									</a>									
								</li>

								

								
								
								<li class="menu-header">
									--  Accounts Menus
								</li>	
								
								<li>
									<a href="<?php echo base_url()?>dashboard/accounts/result">
										<span class="has-icon">
											<i class="icon-chat_bubble_outline"></i>
										</span>
										<span class="nav-title">Accounts</span>
									</a>
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/invoice/history">
										<span class="has-icon">
											<i class="icon-chat_bubble_outline"></i>
										</span>
										<span class="nav-title">Invoice History</span>
									</a>
								</li>
								
								