								
								<li class="active selected">
									<a href="<?php echo base_url()?>dashboard" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-dashboard"></i>
										</span>
										<span class="nav-title">Dashboards</span>
									</a>
									
								</li>
								
								<li>
									<a href="<?php echo base_url()?>dashboard/accounts/result">
										<span class="has-icon">
											<i class="icon-chat_bubble_outline"></i>
										</span>
										<span class="nav-title">Accounts</span>
									</a>
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/invoice/history">
										<span class="has-icon">
											<i class="icon-chat_bubble_outline"></i>
										</span>
										<span class="nav-title">Invoice History</span>
									</a>
								</li>