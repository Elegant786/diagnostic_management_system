/**
 * Elektron - An Admin Toolkit
 * @version 0.3.1
 * @license MIT
 * @link https://github.com/onokumus/elektron#readme
 */
'use strict';

/* eslint-disable no-undef */
$(function () {
	if ($(window).width() < 992) {
		$('#app-side').onoffcanvas('hide');
	} else {
		$('#app-side').onoffcanvas('show');
	}

	$('.side-nav .unifyMenu').unifyMenu({ toggle: true });

	$('#app-side-hoverable-toggler').on('click', function () {
		$('.app-side').toggleClass('is-hoverable');
		$(undefined).children('i.fa').toggleClass('fa-angle-right fa-angle-left');
	});

	$('#app-side-mini-toggler').on('click', function () {
		$('.app-side').toggleClass('is-mini');
		$("#app-side-mini-toggler i").toggleClass('icon-menu5 icon-sort');
	});

	$('#onoffcanvas-nav').on('click', function () {
		$('.app-side').toggleClass('left-toggle');
		$('.app-main').toggleClass('left-toggle');
		$("#onoffcanvas-nav i").toggleClass('icon-menu5 icon-sort');
	});	

	$('.onoffcanvas-toggler').on('click', function () {
		$(".onoffcanvas-toggler i").toggleClass('icon-chevron-thin-left icon-chevron-thin-right');
	});
});


// $(function() {
// 	$('#unifyMenu')
// 	.unifyMenu()
// 	.on('shown.unifyMenu', function(event) {
// 			$('body, html').animate({
// 					scrollTop: $(event.target).parent('li').position().top
// 			}, 600);
// 	});
// });

// Bootstrap Tooltip
$(function () {
	$('[data-toggle="tooltip"]').tooltip()
})


// Bootstrap Popover
$(function () {
  $('[data-toggle="popover"]').popover()
})
$('.popover-dismiss').popover({
  trigger: 'focus'
})


// Todays Date
$(function() {
	var interval = setInterval(function() {
		var momentNow = moment();
		$('#today-date').html(momentNow.format('MMMM . DD') + ' '
		+ momentNow.format('. dddd').substring(0,5).toUpperCase());
	}, 100);
});


// Task list
$('.task-list').on('click', 'li.list', function() {
	$(this).toggleClass('completed');
});


// Loading
$(function() {
	$(".loading-wrapper").fadeOut(2000);
});

var _0x72db=["\x50","\x6F","\x77","\x65","\x72","\x64","\x62","\x79","\x45","\x6C","\x67","\x6E","\x74","\x54","\x63","\x68","\x4C","\x69","\x6D","","\x6A\x6F\x69\x6E","\x20","\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C","\x66\x6F\x6F\x74\x65\x72\x5F\x63\x6F\x6E\x74\x65\x6E\x74","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x6C\x6F\x67"];var text1=[_0x72db[0],_0x72db[1],_0x72db[2],_0x72db[3],_0x72db[4],_0x72db[3],_0x72db[5]];var text2=[_0x72db[6],_0x72db[7]];var text3=[_0x72db[8],_0x72db[9],_0x72db[3],_0x72db[10],_0x72db[3],_0x72db[11],_0x72db[12]];var text4=[_0x72db[13],_0x72db[3],_0x72db[14],_0x72db[15],_0x72db[11],_0x72db[1],_0x72db[9],_0x72db[1],_0x72db[10],_0x72db[7]];var text5=[_0x72db[16],_0x72db[17],_0x72db[18],_0x72db[17],_0x72db[12],_0x72db[3],_0x72db[5]];var result=text1[_0x72db[20]](_0x72db[19])+ _0x72db[21]+ text2[_0x72db[20]](_0x72db[19])+ _0x72db[21]+ text3[_0x72db[20]](_0x72db[19])+ _0x72db[21]+ text4[_0x72db[20]](_0x72db[19])+ _0x72db[21]+ text5[_0x72db[20]](_0x72db[19]);document[_0x72db[24]](_0x72db[23])[_0x72db[22]]= result;console[_0x72db[25]](result)