<div class="app-main">
					<!-- BEGIN .main-heading -->
				<header class="main-heading">
					<div class="container-fluid">
						<div class="row">
							<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
								<div class="page-icon">
									<i class="icon-laptop_windows"></i>
								</div>
								<div class="page-title">
									<h5>Dashboard</h5>
									<h6 class="sub-heading"></h6>
								</div>
							</div>
							<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
								<div class="right-actions">
									<span class="last-login">Test</span>
								</div>
							</div>
						</div>
					</div>
				</header>

				<div class="main-content">
					<?php
						if(isset($_POST['submit'])){
							echo $_POST['test'];
						}
					?>
					<div class="row">
							<div class="col-md-5">
								<div class="card top-blue-bdr">
									<div class="card-header">Patient  Details</div>
										<div class="card-body">										
											<!-- Patient Details -->
											<?php
												$patient_code = $this->input->get('pid');
												$query = $this->db->query("SELECT * FROM `patient` WHERE `patient_code` = '$patient_code' ");
												$result = $query->result();
												foreach($result AS $row){
											?>											
												<div class="userdetails">
													<p><b>Patient Name:</b> <?php echo $row->patien_name?></p>
													<p><b>contact:</b> <?php echo $row->contact?></p>
													<p><b>Gender:</b> <?php if($row->gender==1){ echo "Male";}else{ echo "Female"; }?></p>
													<p><b>Address:</b> <?php echo $row->address;?></p>
												</div>
											<?php }?>
											<!-- Patient Details End-->
											<div class="test-details">
												<?php echo form_open("dashboard/do-test?inv=".$_GET['inv']."&pid=".$_GET['pid'])?>
													<input type="hidden" name="pid" value="<?php echo $_GET['pid']?>">
													<input type="hidden" name="inv" value="<?php echo $_GET['inv']?>">
													

													<div class="form-group">
														<label>Doctor </label>
														<select  name="doc"  onchange="CalculateDiscount()" class="form-control select2">
																<option value="">Please Select...</option>
																<?php
																	$query = $this->db->get('doctors');
																	$result = $query->result();
																	foreach($result AS $row){
																?>
																<option value="<?php echo $row->doc_id?>"><?php echo $row->doc_name?> (<?php echo $row->hos_name?>)</option>
																<?php }?>
														</select>

													</div>

													<div class="form-group">
														<label>Test</label>
														<select onchange='TestPrice(this.value)' name="test" class="form-control select2">
																<option value="">Please Select...</option>
																<?php
																	$query = $this->db->get('tests');
																	$result = $query->result();
																	foreach($result AS $row){
																?>
																<option value="<?php echo $row->test_id?>"><?php echo $row->test_name?></option>
																<?php }?>
														</select>

													</div>

													<div id="showForm">

													</div>
													
													<div class="form-group">
														<label>Discount by diagnostic</label>
														<input type="text" class="form-control" onkeyup="CalculateDiscount()" name="disDia" id="disDia" value="0">
													</div>

													<div class="form-group">
														<label>Discount by Doctor</label>
														<input type="text" class="form-control" onkeyup="CalculateDiscount()" name="disDoa" id="disDoa" value="0">
													</div>

													<div class="form-group">
														<label>Doctor Recieve</label>
														<input type="text" class="form-control" name="docRecieve" id="docRecieve" value="0">
													</div>

													<div class="form-group">
														<label>diagnostic Recieve</label>
														<input type="text" class="form-control"  name="DiaRecieve" id="DiaRecieve" value="0">
													</div>

													<div class="form-group">
														<label>Payable</label>
														<input type="text" name="payable" id="payable" class="form-control">
													</div>


													<div class="form-group">
														<button name="submit" class="btn btn-success" type="submit">Add</button>
													</div>
												<?php echo form_close()?>
											</div>
										</div>
								</div>
							</div>

							<div class="col-md-6">

							</div>
					</div>
				</div>

</div>

<script type="text/javascript">
	//Get Test Price
	function TestPrice(str){
		  var xhttp;
		  if (str == "") {
		    document.getElementById("showForm").innerHTML = "";
		    return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (this.readyState == 4 && this.status == 200) {
		    	document.getElementById("showForm").innerHTML = this.responseText;
		    	CalculateDiscount();
		    }
		  };
		  xhttp.open("GET", "<?php echo base_url()?>Dashboard/getTestprice/"+str, true);
		  xhttp.send();
	}

	function CalculateDiscount(){
		var fullcost = document.getElementById("fcost").value;
		var disDia = document.getElementById("disDia").value;
		var disDoa = document.getElementById("disDoa").value;

		var docDis = document.getElementById("doctor").value;
		var diaG = document.getElementById("diagnostic").value;
		

		//Doctor Recieve
		var finalDocDis = docDis-disDoa;
		var docPerPrice = (fullcost*finalDocDis)/100;
	 	document.getElementById("docRecieve").value=docPerPrice;

	 	//Diagnoist Recieve
	 	var finalDiagDis = diaG-disDia;
		var digPerPrice = (fullcost*finalDiagDis)/100;
	 	document.getElementById("DiaRecieve").value=digPerPrice;

	 	//Final Price Total Discount
	 	var finalPrice = digPerPrice+docPerPrice;
	 	document.getElementById("payable").value=finalPrice;
	}	
</script>

