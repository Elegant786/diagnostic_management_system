<!doctype html>
<html lang="en">
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="Unify Admin Panel" />
		<meta name="keywords" content="Admin, Dashboard, Bootstrap4, Sass, CSS3, HTML5, Responsive Dashboard, Responsive Admin Template, Admin Template, Best Admin Template, Bootstrap Template, Themeforest" />
		<meta name="author" content="Bootstrap Gallery" />
		<link rel="shortcut icon" href="img/favicon.ico" />
		<title>Diagnostic | Dashboard</title>
		
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
		
		<!-- Common CSS -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/fonts/icomoon/icomoon.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/css/main.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css" />

		<!-- Other CSS includes plugins - Cleanedup unnecessary CSS -->
		<!-- Chartist css -->
		<link href="<?php echo base_url()?>assets/vendor/chartist/css/chartist.min.css" rel="stylesheet" />
		<link href="<?php echo base_url()?>assets/vendor/chartist/css/chartist-custom.css" rel="stylesheet" />

	</head>
	<body>

		<!-- Loading starts -->
		<div class="loading-wrapper">
			<div class="loading">
				<div class="img"></div>
				<span></span>
				<span></span>
				<span></span>
				<span></span>
				<span></span>
			</div>
		</div>
		<!-- Loading ends -->

		<!-- BEGIN .app-wrap -->
		<div class="app-wrap">
			<!-- BEGIN .app-heading -->
			<header class="app-header">
				<div class="container-fluid">
					<div class="row gutters">
						<div class="col-xl-5 col-lg-5 col-md-5 col-sm-3 col-4">
							<a class="mini-nav-btn" href="#" id="app-side-mini-toggler">
								<i class="icon-menu5"></i>
							</a>
							<a href="#app-side" data-toggle="onoffcanvas" class="onoffcanvas-toggler" aria-expanded="true">
								<i class="icon-chevron-thin-left"></i>
							</a>
						</div>
						<div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-4">
							<a href="index-2.html" class="logo">
								<img src="<?php echo base_url()?>assets/img/unify.png" alt="Elegant Technology" />
							</a>
						</div>
						<div class="col-xl-5 col-lg-5 col-md-5 col-sm-3 col-4">
							<ul class="header-actions">
								<!--<li class="dropdown">
									<a href="#" id="notifications" data-toggle="dropdown" aria-haspopup="true">
										<i class="icon-notifications_none"></i>
										<span class="count-label"></span>
									</a>
									<div class="dropdown-menu dropdown-menu-right lg" aria-labelledby="notifications">
										<ul class="imp-notify">
											<li>
												<div class="icon">W</div>
												<div class="details">
													<p><span>Wilson</span> The best Dashboard design I have seen ever.</p>
												</div>
											</li>
											<li>
												<div class="icon">J</div>
												<div class="details">
													<p><span>John Smith</span> Jhonny sent you a message. Read now!</p>
												</div>
											</li>
											<li>
												<div class="icon secondary">R</div>
												<div class="details">
													<p><span>Justin Mezzell</span> Stella, Added you as a Friend. Accept it!</p>
												</div>
											</li>
										</ul>
									</div>
								</li>-->
								
								<li class="dropdown">
									<a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
										<img class="avatar" src="<?php echo base_url()?>assets/img/user.png" alt="User Thumb" />
										<span class="user-name"><?php echo $this->session->userdata('name')?></span>
										<i class="icon-chevron-small-down"></i>
									</a>
									<div class="dropdown-menu lg dropdown-menu-right" aria-labelledby="userSettings">
										<ul class="user-settings-list">
											<li>
												<a href="profile.html">
													<div class="icon">
														<i class="icon-account_circle"></i>
													</div>
													<p>Profile</p>
												</a>
											</li>
											<li>
												<a href="profile.html">
													<div class="icon red">
														<i class="icon-cog3"></i>
													</div>
													<p>Settings</p>
												</a>
											</li>
											<li>
												<a href="filters.html">
													<div class="icon yellow">
														<i class="icon-schedule"></i>
													</div>
													<p>Activity</p>
												</a>
											</li>
										</ul>
										<div class="logout-btn">
											<a href="<?php echo base_url()?>UserController/Logout" class="btn btn-primary">Logout</a>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</header>
			<!-- END: .app-heading -->
			<!-- BEGIN .app-container -->
			<div class="app-container">
				<!-- BEGIN .app-side -->
				<aside class="app-side" id="app-side">
					<!-- BEGIN .side-content -->
					<div class="side-content ">
						<!-- BEGIN .user-actions -->
						<ul class="user-actions">
							<li>
								<a href="#">
									<i class="icon-event_note"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="icon-rate_review"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="icon-drafts"></i>
									<span class="count-label red"></span>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="icon-assignment_turned_in"></i>
									<span class="count-label"></span>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="icon-photo_camera"></i>
								</a>
							</li>
							<li>
								<a href="#" data-toggle="tooltip" data-placement="top" title="Secured">
									<i class="icon-verified_user"></i>
								</a>
							</li>
						</ul>
						<!-- END .user-actions -->
						<!-- BEGIN .side-nav -->
						<nav class="side-nav">
							<!-- BEGIN: side-nav-content -->
							<ul class="unifyMenu" id="unifyMenu">
								<li class="active selected">
									<a href="<?php echo base_url()?>dashboard" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-dashboard"></i>
										</span>
										<span class="nav-title">Dashboards</span>
									</a>
									
								</li>
								
								<li>
									<?php
										$query = $this->db->get('patient');
										if($query->num_rows()>=0){
											$num = $query->num_rows()+1;
											$pid = date("ydmh").$num;
									?>


									<a href="<?php echo base_url()?>dashboard/new-test?pid=<?php echo $pid?>" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">New test</span>
									</a>
									<?php }?>
								</li>
								

								<li>
									<a href="<?php echo base_url()?>dashboard/new-doctor" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-users"></i>
										</span>
										<span class="nav-title">Doctor Management</span>
									</a>
									
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/test-management" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-new-message"></i>
										</span>
										<span class="nav-title">Test Management</span>
									</a>
									
								</li>
								
								
								<li>
									<a href="<?php echo base_url()?>dashboard/accounts/result">
										<span class="has-icon">
											<i class="icon-chat_bubble_outline"></i>
										</span>
										<span class="nav-title">Accounts</span>
									</a>
								</li>
								
								<li class="menu-header">
									-- Menu Heading
								</li>
								
							</ul>
							<!-- END: side-nav-content -->
						</nav>
						<!-- END: .side-nav -->
					</div>
					<!-- END: .side-content -->
				</aside>
				<!-- END: .app-side -->

				<!-- BEGIN .app-main -->
				
					<!-- END: .main-heading -->
					<!-- BEGIN .main-content -->
						<?php
							if(isset($page)){
								$this->load->view('pages/'.$page);
							}
						?>
					<!-- END: .main-content -->
				
				<!-- END: .app-main -->
			</div>
			<!-- END: .app-container -->
			<!-- BEGIN .main-footer -->
			<footer class="main-footer fixed-btm">
				Copyright Elegent Technology Limited <?php date('Y')?>.
			</footer>
			<!-- END: .main-footer -->
		</div>
		<!-- END: .app-wrap -->

		<!-- jQuery first, then Tether, then other JS. -->
		<script src="<?php echo base_url()?>assets/js/jquery.js"></script>
		<script src="<?php echo base_url()?>assets/js/tether.min.js"></script>
		<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/unifyMenu/unifyMenu.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/onoffcanvas/onoffcanvas.js"></script>
		<script src="<?php echo base_url()?>assets/js/moment.js"></script>

		<!-- Slimscroll JS -->
		<script src="<?php echo base_url()?>assets/vendor/slimscroll/slimscroll.min.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/slimscroll/custom-scrollbar.js"></script>

		<!-- Chartist JS -->
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/chartist.min.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/chartist-tooltip.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/custom/custom-line-chart.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/custom/custom-line-chart1.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/custom/custom-area-chart.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/custom/donut-chart2.js"></script>
		<script src="<?php echo base_url()?>assets/vendor/chartist/js/custom/custom-line-chart4.js"></script>

		<!-- Common JS -->
		<script src="<?php echo base_url()?>assets/js/common.js"></script>
		
	</body>
</html>