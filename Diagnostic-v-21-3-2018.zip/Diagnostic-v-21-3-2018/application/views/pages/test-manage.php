<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Test management</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<span class="last-login"></span>
									</div>
								</div>
							</div>
						</div>
					</header>

					<div class="main-content">
						<div class="row">
							<?php
								if(isset($_POST['submit'])){
									$name = $this->input->post('name');
									$fee = $this->input->post('fee');
									$doc_per = $this->input->post('doc_per');
									$dia_per = $this->input->post('dia_per');
									$attr = array(
										"test_name"   => $name,
										"test_fee"   => $fee,
										"doc_per"   => $doc_per,
										"dia_per"   => $dia_per
									);
									if($this->db->insert('tests',$attr)==TRUE){
										echo " <div class='col-md-12'> <div class='alert bg-success text-center font-white'> Test Added</div> </div>";
									}else{
										echo "<div class='col-md-12'> <div class='alert bg-success text-center font-white'>Test not Added</div> </div>";
									}
								}

								if(isset($_POST['update'])){
									$name = $this->input->post('name');
									$fee = $this->input->post('fee');
									$doc_per = $this->input->post('doc_per');
									$dia_per = $this->input->post('dia_per');
									$id = $this->input->post('id');
									$attr = array(
										"test_name"   => $name,
										"test_fee"   => $fee,
										"doc_per"   => $doc_per,
										"dia_per"   => $dia_per
									);
									$this->db->where('test_id',$id);
									if($this->db->update('tests',$attr)==TRUE){
										echo "<div class='col-md-12'> <div class='alert bg-success text-center font-white'> Test Updated</div> </div>";
									}else{
										echo "<div class='col-md-12'> <div class='alert bg-success text-center font-white'>Test not Updated</div> </div>";
									}
								}
							?>
							
							<?php
								if($this->uri->segment(3)){
							?>
								
								<div class="col-md-4">
									<div class="card top-blue-bdr">
										<div class="card-header">Edit Test</div>
											<div class="card-body">
												<?php echo form_open()?>

												<?php
													$id = $this->uri->segment(3);
													$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$id' ");
													$result = $query->result();
													foreach($result AS $row){
												?>
													<div class="form-group">
														<label>Test name</label>
														<input type="text" value="<?php echo $row->test_name?>" name="name" class="form-control">
													</div>
													<input type="hidden" name="id" value="<?php echo $row->test_id;?>">
													<div class="form-group">
														<label>Test Fee</label>
														<input type="text" value="<?php echo $row->test_fee?>" name="fee" class="form-control">
													</div>
													
													<div class="form-group">
														<label>Doctor's Percentage(in %)</label>
														<input type="text" value="<?php echo $row->doc_per?>" name="doc_per" class="form-control">
													</div>
												
												
													<div class="form-group">
														<label>Diagnostic Percentage (in %)</label>
														<input type="text" value="<?php echo $row->dia_per?>" name="dia_per" class="form-control">
													</div>
													<?php }?>
												
													<div class="form-group">
														<button name="update" class="btn btn-success" type="submit">Add new</button>
													</div>
															
													
													
												<?php echo form_close()?>
											</div>
										</div>
									</div>
						<?php }else{?>

								<div class="col-md-4">
									<div class="card top-blue-bdr">
										<div class="card-header">Add test</div>
											<div class="card-body">
												<?php echo form_open()?>
													<div class="form-group">
														<label>Test name</label>
														<input type="text" name="name" class="form-control">
													</div>

													<div class="form-group">
														<label>Test Fee</label>
														<input type="text" name="fee" class="form-control">
													</div>
													
													<div class="form-group">
														<label>Doctor's Percentage(in %)</label>
														<input type="text" name="doc_per" class="form-control">
													</div>
												
												
													<div class="form-group">
														<label>Diagnostic Percentage (in %)</label>
														<input type="text" name="dia_per" class="form-control">
													</div>
													<div class="form-group">
														<button name="submit" class="btn btn-success" type="submit">Add new</button>
													</div>
												<?php echo form_close()?>
											</div>
										</div>
									</div>

									<div class="col-md-7">
										<div class="card top-blue-bdr">
												<div class="card-header">All Tests</div>
													<div class="card-body">
															<table class="table table-bordered">
																<thead>
																	<tr>
																		<th>S/N</th>
																		<th>Test Name</th>
																		<th>test Fee</th>
																		<th>Doctor Percentage</th>
																		<th>Diagnostic Percentage</th>
																		<th>Action</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																		$query = $this->db->get('tests');
																		$result = $query->result();
																		foreach($result AS $row){
																			@$sl++;
																	?>
											<tr>
												<td><?php echo $sl;?></td>
												<td><?php echo $row->test_name?></td>
												<td><?php echo $row->test_fee?></td>
												<td><?php echo $row->doc_per?></td>
												<td><?php echo $row->dia_per?></td>
												<td>													
												   <div class="btn-group">
													  <button type="button" class="btn btn-light">Action</button>
													  <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													    <span class="sr-only">Toggle Dropdown</span>
													  </button>
													  <div class="dropdown-menu">
													    <a class="dropdown-item" href="<?php echo base_url()?>dashboard/test-edit/<?php echo $row->test_id;?>">Edit</a>
													    <div class="dropdown-divider"></div>
													    <a class="dropdown-item" href="<?php echo base_url()?>dashboard/test-delete/<?php echo $row->test_id;?>">Delete</a>
													  </div>
													</div>
												</td>
											</tr>
																<?php }?>
																</tbody>
															</table>

													</div>
												</div>
										</div>

									</div>

						<?php }?>
	
								</div>
						</div>
</div>
