<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('UserModel');
		$this->load->model('DashboardModel');
		if($this->UserModel->ChecKLogin()==FALSE){
			redirect('admin-login?action=no-session','refresh');
		}
		
	}

	//Dashbord Page
	public function index(){
		$data = array(
			"page" => 'blank',
			"title"  => "Dashboard | Home"
			
		);
		$this->load->view('index',$data);
	}


	/**********************************
	===============EditDoctor=============
	***************************************/
	//Doctor Create
	public function NewDoctor(){
		$data = array(
			"page"   	=> "new-doctor",
			"title"     => "Dashboard | New doctor"
		);
		$this->load->view('index',$data);
	}
	//Edit Doctor
	public function EditDoctor(){
		$data = array(
			"page"   	=> "new-doctor",
			"title"     => "Dashboard | Edit Doctor"
		);
		$this->load->view('index',$data);
	}
	//Delete Doctor
	public function DeleteDoctor(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `doctors` WHERE `doc_id` = '$id' ");
		redirect('dashboard/new-doctor','refresh');
	}

	/************************************
		Test management
	*****************************************/
	// Test Create
	public function TestManage(){
		$data = array(
			"page"		=> "test-manage",
			"title"		=> "Test Management"
		);
		$this->load->view('index',$data);
	}

	//Edit Test

	public function TestEdit(){
		$data = array(
			"page"		=> "test-manage",
			"title"		=> "Test Edit"
		);
		$this->load->view('index',$data);
	}

	//Delete Test
	public function TestDelete(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `tests` WHERE `test_id` = '$id' ");
		redirect('dashboard/test-management','refresh');
	}

/************************************************************
				Patient Test Management
************************************************************/

	public function NewTest(){
		$data = array(
			"page"	=> "new-test",
			"title" => "Patent Test"
		);
		$this->load->view('index',$data);
	}

	public function DoTest(){
		$data = array(
			"page"	=> "do-test",
			"title" => "Patent Test"
		);
		$this->load->view('index',$data);
	}

	public function PrintInvoice(){
		$this->load->view('invoice');
	}

	public function InvoiceSave(){
		$this->load->view('invoice');
	}

	/*************************************************
			==============Accounts============
	*************************************************/

	public function AccountsResult(){
		$data = array(
			"page"	=> "account-result",
			"title" => "Accounts Report"
		);
		$this->load->view('index',$data);
	}

/*******************************************************************************
						Ajax Functions
*******************************************************************************/
	public function getTestprice(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("SELECT * FROM `tests` WHERE `test_id` = '$id'  ");
		$result['test'] = $query->result();
		$this->load->view('pages/ajax_price',$result);
	}










	#End Of File
}

/* End of file Dashboard.php */
/* Location: ./application/controllers/Dashboard.php */